Reproducibility materials

Adaptive Nested Block-Mean Estimation for Integrated Volatility under Microstructure Noise

This archive contains simulation code, archived path-level results, validation references
and generated tables for the current manuscript. It contains no author-information page
or cover letter. All study data are simulated.

From this archive root:
    python -m pip install -r replication_full/requirements.txt
    python replication_full/reproduce_all.py
The default command validates and reaggregates retained simulation outputs.

To rerun all simulations from the documented random seeds:
    python replication_full/reproduce_all.py --from-raw --workers 3
This full replay is computationally intensive. See replication_table1/README.md and
replication_full/README.md for exact seeds, batch sizes, simulator and comparator details.

The current controlled targets are lambda = .171, .631 and .998. Table 3 is unchanged.
Files labelled superseded or expected are retained provenance or validation references;
they are not substituted for current feasible-estimator outputs.

The manuscript and technical supplement are provided separately. This archive does not
include their LaTeX/PDF files or the manuscript build.py mentioned in older component READMEs.
Use the separate anonymous LaTeX source archive to compile the paper.
