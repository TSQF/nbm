"""Complete reproducible sampling-frequency experiment.

The six low-n cells use the current controlled-design targets and declared PCG64
streams. Earlier target-specific outputs are retained in results/frequency/
superseded; changing the shape target changes the DGP, not the estimator.
The n=234000 cells reuse the current Table 2 baseline outputs.
"""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[key]='1'
import argparse
from concurrent.futures import ProcessPoolExecutor,as_completed
import hashlib
import json
from pathlib import Path
import platform
import sys
import time
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'replication_table1'/'code'))
import controlled_design as design
from common import fixed_phase_pilot,criterion_ratio,CRIT
from nbm_iid_finite_grid import logarithmic_theta_grid,_iid_nbm_for_random_design,_studentizing_avar

PREVIOUS_TARGETS={.171:.15,.631:.60,.998:.97}


def true_phase(target):
    return 2 if target<design.T23 else 3 if target<design.T34 else 4


def run_one(n,target,force=False):
    out=ROOT/'results'/'frequency';out.mkdir(parents=True,exist_ok=True)
    stem=out/f'n{n}_lambda{target:.3f}'
    npz=Path(str(stem)+'.npz');metadata=Path(str(stem)+'.json')
    if not force and npz.exists() and metadata.exists():return dict(n=n,target=target,cached=True)
    design.N=n
    rho=design.rho_for(target);iv=float(rho.mean());iq=float(np.mean(rho*rho))
    grid=logarithmic_theta_grid(.01,.20,121)
    rng=np.random.default_rng(design.SEEDS[target]);before=rng.bit_generator.state
    parts=[];start=time.monotonic();first_hash=None
    for st in range(0,10000,40):
        b=min(40,10000-st);y=design.simulate(rng,rho,b)
        if first_hash is None:first_hash=hashlib.sha256(y[0].tobytes()).hexdigest()
        piv,piq,pom,_,_=fixed_phase_pilot(y,n,phase=3,theta=.05)
        lam,s,theta,m=design.alg2_design(piv,piq,pom)
        est=_iid_nbm_for_random_design(y,n,s,m)
        av=_studentizing_avar(s,m,n,piv,piq,pom)
        z=(est-iv)/(n**(-.25)*np.sqrt(av))
        cr=criterion_ratio(s,m,np.full(b,iv),np.full(b,iq),grid,n)
        parts.append(np.column_stack((lam,s,theta,m,cr,piv,piq,pom,est,av,z,np.abs(z)<=CRIT)))
    values=np.concatenate(parts)
    np.savez_compressed(npz,values=values)
    previous_target=PREVIOUS_TARGETS.get(target)
    previous_metadata=out/'superseded'/f'n{n}_lambda{previous_target:.3f}.json'
    archived=json.loads(previous_metadata.read_text())
    assert archived['n']==n and archived['batch']==40 and archived['replications']==10000
    assert archived['seed']==design.SEEDS[target]
    assert archived['state_before']==before and archived['state_after']==rng.bit_generator.state
    meta=dict(n=n,target=target,replications=10000,batch=40,seed=design.SEEDS[target],
              rng='PCG64',state_before=before,state_after=rng.bit_generator.state,
              historical_low_frequency_seed_recovered=False,
              status='current-target simulation; not an exact replay of an earlier DGP',
              previous_shape_target=PREVIOUS_TARGETS.get(target),
              seed_mapping='The current targets reuse the seeds of the corresponding earlier .15/.60/.97 targets.',
              matching_previous_rng_states_checked=True,
              true_iv=iv,true_iq=iq,true_discrete_lambda=iv/np.sqrt(iq),first_observed_path_sha256=first_hash,
              columns=['lambda_hat','phase','theta','m','cr','pilot_iv','pilot_iq','pilot_omega2','estimate','avar','z','covered'],
              python=platform.python_version(),numpy=np.__version__,elapsed_seconds=time.monotonic()-start)
    metadata.write_text(json.dumps(meta,indent=2)+'\n')
    return dict(n=n,target=target,elapsed_seconds=meta['elapsed_seconds'])


def summarize():
    out=ROOT/'results'/'frequency';rows=[]
    for target in design.TARGETS:
        for n in [23400,46800,234000]:
            if n==234000:
                data=np.load(ROOT.parent/'replication_table1/results'/f'common_lambda_{target:.3f}.npz')
                design_values=data['sp3_theta0.05'];base=data['baseline_pilot_estimate_inference']
                values=np.column_stack((design_values,base))
            else:
                values=np.load(out/f'n{n}_lambda{target:.3f}.npz')['values']
            lam,s,theta,m,cr,piv,piq,pom,est,av,z,covered=values.T
            phase=true_phase(target)
            rows.append(dict(Lambda=target,N=n,ObsPerSecond=n/23400,PilotK=int(np.rint(.05*np.sqrt(n))),
                PhaseRate=float(np.mean(s==phase)),MeanCR=float(cr.mean()),P95CR=float(np.quantile(cr,.95)),
                Coverage=float(covered.mean()),MeanTheta=float(theta.mean()),MeanM=float(m.mean()),
                ZMean=float(z.mean()),ZVar=float(z.var(ddof=1))))
    frame=pd.DataFrame(rows);frame.to_csv(out/'frequency_regenerated.csv',index=False)
    previous=pd.read_csv(out/'superseded/frequency_regenerated.csv')
    changes=[]
    for _,r in frame.iterrows():
        old_target=PREVIOUS_TARGETS[r.Lambda]
        old=previous[(previous.Lambda==old_target)&(previous.N==r.N)].iloc[0]
        for key in ['PhaseRate','MeanCR','P95CR','Coverage','MeanTheta','MeanM','ZMean','ZVar']:
            delta=float(r[key]-old[key])
            changes.append(dict(PreviousLambda=old_target,Lambda=r.Lambda,N=r.N,metric=key,
                                previous=float(old[key]),regenerated=float(r[key]),difference=delta,
                                comparison='Changed controlled shape target; paired RNG draws, not an identical DGP.'))
    pd.DataFrame(changes).to_csv(out/'frequency_change_log.csv',index=False)
    print(frame.to_string(index=False),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--workers',type=int,default=2)
    parser.add_argument('--summarize-only',action='store_true')
    parser.add_argument('--force',action='store_true',help='Regenerate low-frequency paths even when cached results exist.')
    args=parser.parse_args()
    if not args.summarize_only:
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            fs=[pool.submit(run_one,n,t,args.force) for n in [23400,46800] for t in design.TARGETS]
            for f in as_completed(fs):print(json.dumps(f.result()),flush=True)
    summarize()
