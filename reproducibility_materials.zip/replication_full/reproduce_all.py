"""One entry point for retained-output validation or full raw simulation replay."""
import argparse
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
PAPER=ROOT.parent


def call(script,*args):
    subprocess.run([sys.executable,str(script),*map(str,args)],cwd=PAPER,check=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--from-raw',action='store_true',help='Regenerate every observation path used in Tables 1-3 and Table S1.')
    parser.add_argument('--workers',type=int,default=3)
    args=parser.parse_args()
    if args.from_raw:
        for target in [.171,.631,.998]:call(PAPER/'replication_table1/run_common_paths.py','--target',target)
        call(ROOT/'run_table3.py','--workers',args.workers,'--force')
        call(ROOT/'run_frequency.py','--workers',min(args.workers,3),'--force')
    call(PAPER/'replication_table1/validate_and_build_tables.py')
    call(ROOT/'rebuild_tables.py')
    print('All requested table workflows and retained results validated.')
