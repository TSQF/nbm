"""Verbatim archived function bodies; see component_provenance.json."""
import math
import numpy as np
from numba import njit
T=1/252
MU=.05
CORR=-.5
@njit(cache=True)
def _heston_core(z,n_points,max_discard):
    n_returns=n_points-1; batch=z.shape[2]
    mu=.05;kappa=5.;longv=.04;volvol=.5;corr=-.5;T=1/252.;dt=T/n_returns;sdt=math.sqrt(dt);orth=math.sqrt(1-corr*corr)
    x=np.empty((batch,n_points),np.float64);x[:,0]=0.;v=np.full(batch,longv);iv=np.zeros(batch);iq=np.zeros(batch)
    tiv=np.empty((batch,max_discard));tiq=np.empty((batch,max_discard));tail_start=n_points-max_discard
    for ti in range(1,n_points):
        for b in range(batch):
            vp=v[b] if v[b]>0 else 0.;sv=math.sqrt(vp);zv=z[ti-1,0,b];zo=z[ti-1,1,b]
            ivi=vp*dt;iqi=vp*vp*dt*T;dvb=sdt*zv;dpb=sdt*(corr*zv+orth*zo)
            x[b,ti]=x[b,ti-1]+(mu-.5*vp)*dt+sv*dpb;iv[b]+=ivi;iq[b]+=iqi
            if ti>=tail_start:
                idx=ti-tail_start;tiv[b,idx]=ivi;tiq[b,idx]=iqi
            vv=v[b]+kappa*(longv-vp)*dt+volvol*sv*dvb;v[b]=vv if vv>0 else 0.
    return x,iv,iq,tiv,tiq


def simulate_fast(rng,batch,n_points,max_discard):
    z=rng.standard_normal((n_points-1,2,batch))
    return _heston_core(z,n_points,max_discard)


@njit(cache=True)
def heston_core(z, n_returns, kappa, longv, v0, volvol):
    batch=z.shape[2]
    dt=T/n_returns; sdt=math.sqrt(dt); orth=math.sqrt(1-CORR*CORR)
    x=np.empty((batch,n_returns+1),np.float64); x[:,0]=0.0
    v=np.full(batch,v0,np.float64); iv=np.zeros(batch); iq=np.zeros(batch)
    for ti in range(1,n_returns+1):
        for b in range(batch):
            vp=v[b] if v[b]>0 else 0.0
            sv=math.sqrt(vp); zv=z[ti-1,0,b]; zo=z[ti-1,1,b]
            iv[b]+=vp*dt; iq[b]+=vp*vp*dt*T
            x[b,ti]=x[b,ti-1]+(MU-.5*vp)*dt+sv*sdt*(CORR*zv+orth*zo)
            vv=v[b]+kappa*(longv-vp)*dt+volvol*sv*sdt*zv
            v[b]=vv if vv>0 else 0.0
    return x,iv,iq


def msrv_weights(n_returns: int, m_value: int) -> np.ndarray:
    """Zhang (2006) multi-scale weights with exact finite-n noise correction."""

    scales = np.arange(1, m_value + 1, dtype=np.float64)
    scale_mean = scales.mean()
    scale_variance = np.mean(np.square(scales - scale_mean))
    weights = scales * (scales - scale_mean) / (m_value * scale_variance)

    # Enforce sum alpha_i (n+1-K_i)/K_i = 0 without changing sum alpha_i=1.
    delta = (1.0 / (n_returns + 1.0)) / (1.0 - 1.0 / 2.0)
    weights[0] += delta
    weights[1] -= delta
    return weights


def msrv_direct(y: np.ndarray, m_value: int) -> np.ndarray:
    """Direct O(nM) evaluation of the original multi-scale estimator."""

    n_returns = y.shape[1] - 1
    m_value = min(m_value, n_returns)
    weights = msrv_weights(n_returns, m_value)
    estimate = np.zeros(y.shape[0], dtype=np.float64)
    for k_value, weight in enumerate(weights, start=1):
        lag_returns = y[:, k_value:] - y[:, :-k_value]
        average_rv = np.square(lag_returns).sum(axis=1) / k_value
        estimate += weight * average_rv
    return estimate


def msrv_fft(y: np.ndarray, m_value: int) -> np.ndarray:
    """Exact O(n log n) MSRV evaluation through linear autocorrelations.

    For each lag k,

        sum_{i=k}^n (Y_i-Y_{i-k})^2

    is reconstructed from endpoint square sums and the lag-k linear
    autocorrelation.  Zero-padding prevents circular wraparound.  Rows are
    transformed separately so the million-observation experiment remains
    memory bounded.
    """

    n_returns = y.shape[1] - 1
    n_prices = n_returns + 1
    m_value = min(m_value, n_returns)
    weights = msrv_weights(n_returns, m_value)
    scales = np.arange(1, m_value + 1, dtype=np.float64)
    n_fft = 1 << (2 * n_prices - 1).bit_length()
    estimate = np.empty(y.shape[0], dtype=np.float64)

    for row_index, prices in enumerate(y):
        price_squares = np.square(prices)
        total_squares = float(price_squares.sum())
        omitted_left = np.cumsum(price_squares[:m_value])
        omitted_right = np.cumsum(price_squares[:-m_value - 1:-1])

        spectrum = np.fft.rfft(prices, n=n_fft)
        autocorrelation = np.fft.irfft(
            spectrum * np.conjugate(spectrum), n=n_fft
        )[1:m_value + 1]
        lag_square_sums = (
            2.0 * total_squares
            - omitted_left
            - omitted_right
            - 2.0 * autocorrelation
        )
        estimate[row_index] = np.dot(weights, lag_square_sums / scales)

    return estimate


def msrv(y: np.ndarray, m_value: int) -> np.ndarray:
    """Original MSRV, using FFT only when it reduces the workload."""

    n_returns = y.shape[1] - 1
    if n_returns * m_value >= 2_000_000:
        return msrv_fft(y, m_value)
    return msrv_direct(y, m_value)


def return_autocovariances(returns: np.ndarray, max_lag: int) -> np.ndarray:
    """Sample return autocovariances with the manuscript's denominators."""

    values = np.empty((returns.shape[0], max_lag + 1), dtype=np.float64)
    values[:, 0] = np.square(returns).mean(axis=1)
    for lag in range(1, max_lag + 1):
        values[:, lag] = np.mean(
            returns[:, lag:] * returns[:, :-lag], axis=1
        )
    return values


def _whittle_fit_fast(periodogram, frequencies, weights, sample_acov, order, iterations=5):
    p = order + 2
    design = np.empty((frequencies.size, p), dtype=np.float64)
    design[:, 0] = 1.0
    for lag in range(1, p):
        design[:, lag] = 2.0 * (np.cos(lag * frequencies) - 1.0)
    beta = np.empty((periodogram.shape[0], p), dtype=np.float64)
    beta[:, 1:] = sample_acov[:, 1:p] * 1.0e8
    beta[:, 0] = (sample_acov[:, 0] + 2.0 * sample_acov[:, 1:p].sum(axis=1)) * 1.0e8
    floor = 1.0e-5
    beta[:, 0] = np.maximum(beta[:, 0], 10.0 * floor)
    noise_spectrum = beta[:, 1:] @ design[:, 1:].T
    minimum_noise = noise_spectrum.min(axis=1)
    bad = beta[:, 0] + minimum_noise <= floor
    if np.any(bad):
        shrink = np.minimum(1.0, 0.9 * (beta[bad, 0] - floor) / np.maximum(-minimum_noise[bad], floor))
        beta[bad, 1:] *= shrink[:, None]
    for _ in range(iterations):
        fitted = np.maximum(beta @ design.T, floor)
        sw = weights[None, :] * (1.0 / fitted - periodogram / np.square(fitted))
        gradients = sw @ design
        iw = weights[None, :] / np.square(fitted)
        information = np.einsum('bf,fk,fl->bkl', iw, design, design, optimize=True)
        ridge = 1.0e-10 * np.eye(p)[None, :, :]
        steps = np.linalg.solve(information + ridge, gradients[..., None])[..., 0]
        current_fitted = beta @ design.T
        current_obj = np.sum(weights[None, :] * (np.log(current_fitted) + periodogram / current_fitted), axis=1)
        unresolved = np.ones(beta.shape[0], dtype=bool)
        fraction = np.ones(beta.shape[0], dtype=np.float64)
        for _back in range(14):
            if not np.any(unresolved):
                break
            idx = np.flatnonzero(unresolved)
            cand = beta[idx] - fraction[idx, None] * steps[idx]
            cf = cand @ design.T
            valid = (cand[:, 0] > floor) & (np.min(cf, axis=1) > floor)
            obj = np.full(idx.size, np.inf)
            if np.any(valid):
                vf = cf[valid]
                obj[valid] = np.sum(weights[None, :] * (np.log(vf) + periodogram[idx[valid]] / vf), axis=1)
            acc_local = obj <= current_obj[idx]
            if np.any(acc_local):
                acc_idx = idx[acc_local]
                beta[acc_idx] = cand[acc_local]
                unresolved[acc_idx] = False
            fraction[idx[~acc_local]] *= 0.5
    fitted = np.maximum(beta @ design.T, floor)
    objective = np.sum(weights[None, :] * (np.log(fitted) + periodogram / fitted), axis=1)
    return beta[:, 0], objective


def bic_whittle_qmle_fast(returns, sample_acov, max_order=3):
    n_returns = returns.shape[1]
    scaled = returns * 1.0e4
    spectrum = np.fft.rfft(scaled, axis=1)
    periodogram = np.square(np.abs(spectrum)) / n_returns
    frequencies = 2.0 * np.pi * np.arange(periodogram.shape[1]) / n_returns
    weights = np.full(periodogram.shape[1], 2.0)
    weights[0] = 1.0
    if n_returns % 2 == 0:
        weights[-1] = 1.0
    estimates=[]; criteria=[]
    for order in range(max_order+1):
        intercept,obj=_whittle_fit_fast(periodogram,frequencies,weights,sample_acov,order)
        estimates.append(n_returns*intercept/1.0e8)
        criteria.append(obj+(order+2)*math.log(n_returns))
    em=np.column_stack(estimates); cm=np.column_stack(criteria); sel=np.argmin(cm,axis=1)
    return em[np.arange(returns.shape[0]),sel], sel


