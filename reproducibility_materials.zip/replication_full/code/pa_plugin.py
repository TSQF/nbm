"""Prespecified triangular PA plug-in; no evaluation loss or true nuisance input."""
import numpy as np
from numba import njit

PA_A, PA_B, PA_C = 151.0 / 140.0, 12.0, 96.0

def select_pa_window(iv, iq, omega2, n):
    """Minimize A theta IQ + B omega2 IV/theta + C omega2^2/theta^3."""
    theta2 = omega2 * (PA_B*iv + np.sqrt(PA_B**2*iv**2 + 12*PA_A*PA_C*iq))/(2*PA_A*iq)
    raw = np.rint(np.sqrt(theta2*n)).astype(np.int64)
    return np.clip(raw, 4, n), raw

@njit(cache=True)
def triangle_pa_variable(prices, windows):
    """Same finite-k estimator as jacod_2009_triangle, O(n) rolling sums.

    Summation by parts converts the triangle-weighted returns to the
    difference of two adjacent sums of prices, with a zero centre weight
    when k is odd. This includes all n-k+2 preaverages.
    """
    batch, npoints = prices.shape
    n = npoints-1
    out = np.empty(batch)
    for b in range(batch):
        k = windows[b]; half = k//2
        left = 0.0; right = 0.0
        for j in range(half):
            left += prices[b,j]
            right += prices[b,k-half+j]
        sumsq = 0.0; count = n-k+2
        for i in range(count):
            value = (right-left)/k
            sumsq += value*value
            if i+1 < count:
                left += prices[b,i+half]-prices[b,i]
                right += prices[b,i+k]-prices[b,i+k-half]
        psi1 = 0.0; psi2 = 0.0; previous = 0.0
        for j in range(1,k+1):
            g = min(j/k,1-j/k)
            psi1 += (g-previous)**2
            psi2 += g*g
            previous = g
        psi1 *= k; psi2 /= k
        rv=0.0
        for j in range(n):
            rv += (prices[b,j+1]-prices[b,j])**2
        corr = psi1/(2*k*k*psi2)
        out[b]=(n/count*sumsq/(k*psi2)-corr*rv)/(1-corr)
    return out
