"""Regenerate all four Table 3 methods on the original Heston random streams."""
from __future__ import annotations
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[key]='1'
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import hashlib
import json
import math
from pathlib import Path
import platform
import sys
import time

import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'code'))
sys.path.insert(0,str(ROOT.parent/'replication_table1'/'code'))
from legacy_components import simulate_fast,heston_core,msrv,return_autocovariances,bic_whittle_qmle_fast
from pa_plugin import select_pa_window,triangle_pa_variable
from common import fixed_phase_pilot
from controlled_design import alg2_design
from nbm_iid_finite_grid import _iid_nbm_for_random_design

N=234000
PARAMS={'phase3_xi8':(5.,.04,.04,8.),
        'phase2_deep':(20000.,.0029439039109763455,2.9439039109763456,.13564438596419004)}
LABELS={'reference':'Reference Heston','phase3_xi8':'Stochastic stress','phase2_deep':'Transient stress'}
METHODS={'NBM':'Adaptive NBM--FS','PA':'Feasible PA','MSRV':'MSRV (fixed $M=71$)','QMLE':'Whittle (fixed $R=0$)'}


def schedule():
    out=[dict(scenario='reference',seed=s,nsim=250,batch=25)
         for s in [20260923,20260930,*range(20261101,20261119)]]
    out += [dict(scenario='reference',seed=s,nsim=250,batch=50) for s in range(20261301,20261321)]
    for scenario,start in [('phase3_xi8',20261511),('phase2_deep',20261711)]:
        out += [dict(scenario=scenario,seed=s,nsim=250,batch=10) for s in range(start,start+40)]
    return out


def run_one(task,outdir,force=False):
    outdir=Path(outdir);outdir.mkdir(parents=True,exist_ok=True)
    stem=outdir/f"{task['scenario']}_{task['seed']}_{task['nsim']}"
    npz=Path(str(stem)+'.npz');meta_path=Path(str(stem)+'.json')
    if not force and npz.exists() and meta_path.exists():
        return dict(task,cache=True)
    rng=np.random.default_rng(task['seed']);state_before=rng.bit_generator.state
    chunks=[];start=time.monotonic();first_hash=None
    for st in range(0,task['nsim'],task['batch']):
        b=min(task['batch'],task['nsim']-st)
        if task['scenario']=='reference':
            x,iv,iq,_,_=simulate_fast(rng,b,N+1,1)
        else:
            kappa,longv,v0,volvol=PARAMS[task['scenario']]
            z=rng.standard_normal((N,2,b))
            x,iv,iq=heston_core(z,N,kappa,longv,v0,volvol)
        y=x+rng.normal(0,.0005,size=x.shape)
        if first_hash is None:first_hash=hashlib.sha256(y[0].tobytes()).hexdigest()
        piv,piq,pom,_,_=fixed_phase_pilot(y,N,phase=3,theta=.05)
        lam,s,theta,m=alg2_design(piv,piq,pom)
        nbm=_iid_nbm_for_random_design(y,N,s,m)
        k,_=select_pa_window(piv,piq,pom,N)
        pa=triangle_pa_variable(y,k)
        multiscale=msrv(y,71)
        returns=np.diff(y,axis=1)
        ac=return_autocovariances(returns,4)
        whittle,order=bic_whittle_qmle_fast(returns,ac,max_order=0)
        assert np.all(order==0)
        chunks.append(dict(TrueIV=iv,TrueIQ=iq,NBM=nbm,PA=pa,MSRV=multiscale,QMLE=whittle,
                           PilotIV=piv,PilotIQ=piq,PilotOmega2=pom,SelectedS=s,SelectedM=m,
                           SelectedTheta=theta,PAWindow=k,Seed=np.full(b,task['seed']),
                           PathInStream=np.arange(st,st+b)))
    data={key:np.concatenate([c[key] for c in chunks]) for key in chunks[0]}
    expected=np.load(ROOT/'expected'/f"{task['scenario']}_historical.npz")
    mask=expected['Seed']==task['seed']
    for key in ['TrueIV','TrueIQ']:
        np.testing.assert_array_equal(data[key],expected[key][mask][:task['nsim']])
    comparator_diffs={}
    for key in ['MSRV','QMLE']:
        if key in expected.files:
            old=expected[key][mask][:task['nsim']]
            comparator_diffs[key]=float(np.max(np.abs(data[key]-old)))
            np.testing.assert_allclose(data[key],old,atol=2e-12,rtol=1e-9)
    np.savez_compressed(npz,**data)
    metadata=dict(task,n=N,rng='PCG64',state_before=state_before,state_after=rng.bit_generator.state,
                  draw_order='latent normal array (n,2,batch), then noise array (batch,n+1)',
                  first_observed_path_sha256=first_hash,truth_matches_historical_exactly=True,
                  archived_comparator_max_abs_difference=comparator_diffs,
                  elapsed_seconds=time.monotonic()-start,python=platform.python_version(),
                  numpy=np.__version__,pandas=pd.__version__)
    meta_path.write_text(json.dumps(metadata,indent=2)+'\n')
    return dict(task,elapsed_seconds=metadata['elapsed_seconds'])


def summarize(outdir):
    rows=[]
    for scenario,label in LABELS.items():
        files=sorted(Path(outdir).glob(scenario+'_*.npz'))
        packs=[np.load(f) for f in files]
        data={key:np.concatenate([z[key] for z in packs]) for key in ['TrueIV','TrueIQ',*METHODS]}
        assert len(data['TrueIV'])==10000,(scenario,len(data['TrueIV']))
        for key,method in METHODS.items():
            error=data[key]-data['TrueIV'];pilot=key in ['NBM','PA']
            rows.append(dict(Scenario=label,Method=method,PilotPhase=3 if pilot else np.nan,
                PilotTheta=.05 if pilot else np.nan,PilotK=24 if pilot else np.nan,N=len(error),
                Bias=float(error.mean()),Variance=float(error.var(ddof=1)),
                RMSE=float(np.sqrt(np.mean(error**2))),MeanLambda=float(np.mean(data['TrueIV']/np.sqrt(data['TrueIQ'])))))
    frame=pd.DataFrame(rows)
    expected=pd.read_csv(ROOT/'expected/table3_current.csv')
    checks=[]
    for _,r in frame.iterrows():
        old=expected[(expected.Scenario==r.Scenario)&(expected.Method==r.Method)].iloc[0]
        for key in ['N','Bias','Variance','RMSE','MeanLambda']:
            diff=abs(float(r[key])-float(old[key]));tol=1e-13 if key in ['Bias','RMSE'] else 1e-14
            checks.append(dict(Scenario=r.Scenario,Method=r.Method,Metric=key,expected=float(old[key]),actual=float(r[key]),abs_difference=diff,passed=diff<=tol))
    frame.to_csv(Path(outdir)/'table3_regenerated.csv',index=False)
    pd.DataFrame(checks).to_csv(Path(outdir)/'table3_validation.csv',index=False)
    assert all(x['passed'] for x in checks),'Table 3 mismatch; inspect table3_validation.csv.'
    print(frame.to_string(index=False),flush=True)
    print('All Table 3 numerical checks passed.',flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--workers',type=int,default=3)
    parser.add_argument('--smoke',action='store_true');parser.add_argument('--summarize-only',action='store_true')
    parser.add_argument('--force',action='store_true',help='Regenerate paths even when cached results exist.')
    args=parser.parse_args();tasks=schedule();out=ROOT/'results'/('table3_smoke' if args.smoke else 'table3')
    if args.smoke:
        tasks=[tasks[j] for j in [0,20,40,80]]
        tasks=[dict(t,nsim=t['batch']) for t in tasks]
    if not args.summarize_only:
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            futures=[pool.submit(run_one,t,out,args.force) for t in tasks]
            for done,future in enumerate(as_completed(futures),1):
                result=future.result();print(json.dumps(dict(done=done,total=len(tasks),last=result)),flush=True)
    if not args.smoke:summarize(out)
