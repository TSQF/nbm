from __future__ import annotations
import math, os, sys, json, time
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
os.environ.setdefault('OPENBLAS_NUM_THREADS','1'); os.environ.setdefault('OMP_NUM_THREADS','1'); os.environ.setdefault('MKL_NUM_THREADS','1')
import numpy as np, pandas as pd
PKG=Path('/mnt/data/thetap05_compare/fullpkg/NBM_clean84_submission_package')
CODE=PKG/'replication'/'code'; ADD=PKG/'replication'/'additions'/'code'; PH=PKG/'replication'/'phase4_update'
sys.path.insert(0,str(CODE));sys.path.insert(0,str(ADD));sys.path.insert(0,str(PH))
from base_highn import simulate_fast
from frozen_full_pilots import heston_core
from nbm_iid_finite_grid import _grid_design, _iid_nbm_for_random_design, logarithmic_theta_grid
from verify_nested_manuscript_theory import asymptotic_coefficients
from common import fixed_phase_pilot
from pa_plugin import select_pa_window, triangle_pa_variable

N=234000; THETA_P=.05; SP=3; T23=.214428329551;T34=.894738052767;LOW=.01;HIGH=.20;OMEGA=.0005
GRID=logarithmic_theta_grid(LOW,HIGH,121)
SRC=Path('/mnt/data/thetap05_compare/pilot_parallel/NBM_pilot_phase_parallel/results/heston')
OUT=Path('/mnt/data/thetap05_compare/results_table3');OUT.mkdir(parents=True,exist_ok=True)
BASE=Path('/mnt/data/thetap05_compare/alg1/NBM_clean86_tex_source/replication_sources/table3_sp3_bias_variance_rmse.csv')
PARAMS={
 'phase3_xi8':dict(kappa=5.0,longv=.04,v0=.04,volvol=8.0),
 'phase2_deep':dict(kappa=20000.0,longv=.0029439039109763455,v0=2.9439039109763456,volvol=.13564438596419004),
}

def alg2(iv,iq,om):
    lam=iv/np.sqrt(iq);s=np.full(len(iv),4,dtype=np.int64);s[lam<T34]=3;s[lam<T23]=2;theta=np.empty(len(iv))
    for q in (2,3,4):
        mask=s==q
        if not mask.any():continue
        a,b,c=asymptotic_coefficients(q)
        theta[mask]=np.sqrt(om[mask]*(b*iv[mask]+np.sqrt(b*b*iv[mask]**2+12*a*c*iq[mask]))/(2*a*iq[mask]))
    theta=np.clip(theta,LOW,HIGH);m=np.rint(theta*math.sqrt(N)).astype(np.int64)
    return lam,s,theta,m

def task_from_path(p):
    name=p.stem; parts=name.split('_')
    if name.startswith('reference_'): return 'reference',int(parts[1]),int(parts[2])
    return '_'.join(parts[:2]),int(parts[2]),int(parts[3])

def run_one(srcpath):
    srcpath=Path(srcpath);scenario,seed,nsim=task_from_path(srcpath);out=OUT/srcpath.name
    with np.load(srcpath) as z:
        truth=z['TrueIV'].copy();trueiq=z['TrueIQ'].copy();bs=int(z['BatchSize'][0])
    a1s=np.empty(nsim,dtype=np.int8); a1m=np.empty(nsim,dtype=np.int16); a1e=np.empty(nsim)
    a2s=np.empty(nsim,dtype=np.int8); a2m=np.empty(nsim,dtype=np.int16); a2th=np.empty(nsim); a2e=np.empty(nsim)
    pae=np.empty(nsim); paw=np.empty(nsim,dtype=np.int32)
    pivall=np.empty(nsim);piqall=np.empty(nsim);pomall=np.empty(nsim);plam=np.empty(nsim)
    rng=np.random.default_rng(seed);t0=time.time()
    for st in range(0,nsim,bs):
        cur=min(bs,nsim-st);sl=slice(st,st+cur)
        if scenario=='reference': x,iv,iq,_,_=simulate_fast(rng,cur,N+1,1)
        else:
            par=PARAMS[scenario];zdraw=rng.standard_normal((N,2,cur));x,iv,iq=heston_core(zdraw,N,par['kappa'],par['longv'],par['v0'],par['volvol'])
        np.testing.assert_array_equal(iv,truth[sl]);np.testing.assert_array_equal(iq,trueiq[sl])
        y=x+rng.normal(0,OMEGA,size=x.shape)
        piv,piq,pom,_,_=fixed_phase_pilot(y,N,phase=SP,theta=THETA_P)
        s1,_,m1,_=_grid_design(piv,piq,pom,GRID,N,1)
        lam,s2,th2,m2=alg2(piv,piq,pom)
        e1=_iid_nbm_for_random_design(y,N,s1,m1); e2=_iid_nbm_for_random_design(y,N,s2,m2)
        kw,_=select_pa_window(piv,piq,pom,N); pe=triangle_pa_variable(y,kw)
        pivall[sl]=piv;piqall[sl]=piq;pomall[sl]=pom;plam[sl]=lam
        a1s[sl]=s1;a1m[sl]=m1;a1e[sl]=e1;a2s[sl]=s2;a2m[sl]=m2;a2th[sl]=th2;a2e[sl]=e2;pae[sl]=pe;paw[sl]=kw
    np.savez_compressed(out,TrueIV=truth,TrueIQ=trueiq,PilotIV=pivall,PilotIQ=piqall,PilotOmega2=pomall,PilotLambda=plam,
                        Alg1S=a1s,Alg1M=a1m,Alg1NBM=a1e,Alg2S=a2s,Alg2M=a2m,Alg2Theta=a2th,Alg2NBM=a2e,PA=pae,PAWindow=paw,Seed=np.array([seed]))
    return {'scenario':scenario,'seed':seed,'elapsed':time.time()-t0}

def summarize():
    base=pd.read_csv(BASE)
    rows=[];diag=[]
    for scenario,label in [('reference','Reference Heston'),('phase3_xi8','Stochastic stress'),('phase2_deep','Transient stress')]:
        ps=sorted(OUT.glob(f'{scenario}_*.npz')); packs=[]
        for p in ps:
            with np.load(p) as z:packs.append({k:z[k] for k in z.files})
        keys=['TrueIV','TrueIQ','PilotLambda','Alg1S','Alg1M','Alg1NBM','Alg2S','Alg2M','Alg2Theta','Alg2NBM','PA','PAWindow']
        d={k:np.concatenate([x[k] for x in packs]) for k in keys}; truth=d['TrueIV']
        for alg,key in [('Algorithm 1 NBM--FS','Alg1NBM'),('Algorithm 2 NBM--FS','Alg2NBM'),('Feasible PA','PA')]:
            err=d[key]-truth;rows.append({'Scenario':label,'Method':alg,'PilotPhase':3,'PilotTheta':THETA_P,'PilotK':int(np.rint(THETA_P*math.sqrt(N))),'N':len(err),
                                          'Bias':float(err.mean()),'Variance':float(err.var(ddof=1)),'RMSE':float(np.sqrt(np.mean(err*err))),
                                          'MeanLambda':float(np.mean(d['TrueIV']/np.sqrt(d['TrueIQ'])))})
        for method in ['MSRV (fixed $M=71$)','Whittle (fixed $R=0$)']:
            r=base[(base.Scenario==label)&(base.Method==method)].iloc[0]
            rows.append({'Scenario':label,'Method':method,'PilotPhase':np.nan,'PilotTheta':np.nan,'PilotK':np.nan,'N':int(r.N),'Bias':float(r.Bias),'Variance':float(r.Variance),'RMSE':float(r.RMSE),'MeanLambda':float(r.MeanLambda)})
        diag.append({'Scenario':label,'N':len(truth),'MeanTrueLambda':float(np.mean(d['TrueIV']/np.sqrt(d['TrueIQ']))),'MeanPilotLambda':float(np.mean(d['PilotLambda'])),
                     'Alg1S2':float(np.mean(d['Alg1S']==2)),'Alg1S3':float(np.mean(d['Alg1S']==3)),'Alg1S4':float(np.mean(d['Alg1S']==4)),'Alg1MeanM':float(np.mean(d['Alg1M'])),
                     'Alg2S2':float(np.mean(d['Alg2S']==2)),'Alg2S3':float(np.mean(d['Alg2S']==3)),'Alg2S4':float(np.mean(d['Alg2S']==4)),'Alg2MeanM':float(np.mean(d['Alg2M'])),'Alg2MeanTheta':float(np.mean(d['Alg2Theta'])),
                     'PAMeanWindow':float(np.mean(d['PAWindow']))})
    df=pd.DataFrame(rows);dg=pd.DataFrame(diag);df.to_csv(OUT/'theta05_table3_both_algorithms.csv',index=False);dg.to_csv(OUT/'theta05_table3_diagnostics.csv',index=False)
    print('\nTABLE3\n',df.to_string(index=False));print('\nDIAG\n',dg.to_string(index=False))

if __name__=='__main__':
    paths=sorted(SRC.glob('reference_*.npz'))+sorted(SRC.glob('phase3_xi8_*.npz'))+sorted(SRC.glob('phase2_deep_*.npz'))
    with ProcessPoolExecutor(max_workers=3) as ex:
        fs=[ex.submit(run_one,p) for p in paths]
        done=0
        for f in as_completed(fs):
            done+=1; r=f.result()
            if done%10==0: print(json.dumps({'done_tasks':done,'total_tasks':len(fs),'last':r}),flush=True)
    summarize()
