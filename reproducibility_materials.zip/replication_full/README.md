# Complete Table 3 and sampling-frequency replication

This directory supplies executable simulation, estimation, aggregation and table-generation workflows. It uses the shared direct plug-in implementation in `../replication_table1/code/`; keep the complete source/submission package together.

## Run

From the package root:

```bash
python -m pip install -r replication_full/requirements.txt
python replication_full/reproduce_all.py
```

The default command checks the archived per-path results, reaggregates Tables 1–3 and Supplement Table S1, and rebuilds the generated table inputs. To regenerate the observations, nuisance estimates, selected designs and all comparator outputs from random seeds:

```bash
python replication_full/reproduce_all.py --from-raw --workers 3
```

This includes all controlled experiments, all 30,000 Heston paths, and all 60,000 newly documented low-frequency paths. The high-frequency sensitivity rows are the same 30,000 controlled baseline paths used in Table 2. No DGP truth is supplied to any feasible estimator or its tuning. Truths are used only for evaluation and stream-validation assertions.

Independent entry points:

```bash
python replication_full/run_table3.py --force --workers 3
python replication_full/run_frequency.py --force --workers 2
python replication_full/rebuild_tables.py
python replication_full/check_random_window_obstruction.py
python build.py
```

Without `--force`, completed simulation shards are reused. `run_table3.py --smoke` checks the first batch of each of the four stream configurations in a separate output directory. Parallel workers do not share RNG state: each task owns one PCG64 generator. Changing the per-stream batch sizes changes the experiment; changing the worker count does not.

## Table 3

The original `run_theta05_table3.py` was recovered from `thetap05_algorithm1_algorithm2_results.zip`. Its simulator and comparator dependencies were recovered from `NBM_clean84_submission_package.zip`. The new driver computes **all four methods**, including MSRV and fixed-order Whittle, from the same observations; it does not import their old summary values as outputs.

| Scenario | Seeds | Paths/seed | Batch |
|---|---|---:|---:|
| Reference, original half | 20260923, 20260930, 20261101–20261118 | 250 | 25 |
| Reference, extension | 20261301–20261320 | 250 | 50 |
| Stochastic stress | 20261511–20261550 | 250 | 10 |
| Transient stress | 20261711–20261750 | 250 | 10 |

Each batch first draws the latent standard-normal array `(234000,2,batch)` and then the observation-noise array `(batch,234001)`. Reference and stress simulators retain their respective original floating-point operation orders. Preserving those orders reproduces historical IV/IQ targets exactly. The full-precision transient parameters are in `run_table3.py`.

The pilot is `(s_p,theta_p)=(3,.05)`. NBM uses the direct phase map and closed-form scale, PA uses its feasible nuisance-based bandwidth, MSRV fixes M=71, and Whittle fixes R=0 and five scoring iterations. `component_provenance.json` records archived function-body hashes. `code/legacy_components.py` retains those functions verbatim; no historical path or installed archive is required at runtime.

The `expected/` data contain the retained Table 3 summary and historical latent path targets, plus stress-comparator outputs. They are validation references, never simulator or estimator inputs. `results/table3/` contains 120 regenerated NPZ shards, their run metadata, a rebuilt summary, and 60 numerical checks. All displayed Table 3 entries remain unchanged.

## Sampling-frequency sensitivity

The current controlled shape targets are lambda=.171, .631 and .998, matching the rounded mean pathwise lambdas of the unchanged Table 3 environments. These are fixed controlled targets, not Heston paths. The six low-frequency cells have been rerun at the new targets; the pilot, final estimator, CR reference, sample sizes and replication counts are unchanged. The former .15/.60/.97 paths and summary remain in `results/frequency/superseded/`. The even earlier low-frequency summary in `expected/frequency_previous.csv` remains a historical reference; its original seed/batch specification was not recovered.

For n=23,400 and 46,800, use 10,000 paths per shape, batches of 40, and the following fixed seeds: lambda=.171 → 3657603516; .631 → 575453803; .998 → 3123275394. These respectively reuse the previous .15/.60/.97 seeds, so each updated shape receives the same standard-normal and observation-noise draws as its preceding shape at the same n. This does not reproduce the previous observations because the latent variance shape changes. A batch draws the latent increments before observation noise. These seed labels also occur in the high-frequency experiment, but different array sizes imply different paths.

`results/frequency/` stores the six new path arrays, complete run metadata, regenerated nine-row summary, and old/new shape comparison log. The log explicitly maps each new target to its former target rather than testing identical-DGP replay. The current paper reads `tables/sampling_frequency.tex`, rebuilt from the regenerated summary. The n=234,000 rows reuse the current Table 2 NPZ baseline and are not simulated again. `python replication_full/rebuild_tables.py --frequency-only` rebuilds only this supplementary table.

## Environment and integrity

`requirements.txt` pins the tested numerical dependencies. `environment.json` records the interpreter and package versions. `SHA256SUMS.csv` maps deliverable bytes; `VALIDATION.json` records the numerical and portability checks. Floating-point changes across BLAS/compiler/platform versions can affect the last digits; the driver checks both original path truths and numerical summaries within stated tolerances.

## Details accompanying the concise simulation appendix

Supplement S4 retains the data-generating models, finite-sample comparator definitions and sampling-frequency table. Exact RNG contracts, batching, output validation and provenance stay in this directory and `../replication_table1/`; no experiment is changed by this editorial reduction. For Tables 1–2, the latter README records the three controlled seeds, batch size 40, PCG64 draw order and common-path pilot settings. For Table 3, the seed/batch table and Gaussian array shapes above specify all 120 streams.

The paired RMSE diagnostic uses common paths within each Heston environment. If errors are $e_{a,i},e_{b,i}$ and $\widehat r_a=(B^{-1}\sum_i e_{a,i}^2)^{1/2}$ (similarly for $b$), its delta-method Monte Carlo standard error is the sample standard deviation of

$$
\frac{e_{a,i}^2-\widehat r_a^2}{2\widehat r_a}
-\frac{e_{b,i}^2-\widehat r_b^2}{2\widehat r_b}
$$

divided by $\sqrt B$. This is an archived diagnostic; Table 3 reports bias, variance and RMSE.

This estimation-focused version reports nominal interval coverage empirically; it claims no selected-window CLT or asymptotic coverage guarantee. The target update changes only the controlled variance shapes and their numerical outputs; the estimator, RNG seeds and Table 3 experiment are unchanged.
