"""Aggregate saved path outputs and regenerate Table 3 / Supplement Table S1."""
from pathlib import Path
import pandas as pd
from run_table3 import summarize as summarize_table3
from run_frequency import summarize as summarize_frequency
import controlled_design as design

ROOT=Path(__file__).resolve().parent
PAPER=ROOT.parent


def build():
    summarize_table3(ROOT/'results/table3')
    summarize_frequency()
    table3=pd.read_csv(ROOT/'results/table3/table3_regenerated.csv')
    display={'Adaptive NBM--FS':'Adaptive NBM--FS','Feasible PA':'Feasible PA',
             'MSRV (fixed $M=71$)':'MSRV, fixed $M=71$','Whittle (fixed $R=0$)':'Whittle, fixed $R=0$'}
    lines=[r'\begin{tabular}{lrrr}',r'\toprule',r'Method & Bias & Variance & RMSE\\',r'\midrule']
    for index,(scenario,label) in enumerate([('Reference Heston','Reference Heston'),
            ('Stochastic stress','Stochastic-volatility stress'),('Transient stress','Transient-heterogeneity stress')]):
        group=table3[table3.Scenario==scenario]
        if index:lines.append(r'\addlinespace')
        lines.append(r'\multicolumn{4}{l}{\textit{Panel '+chr(65+index)+'. '+label+
                     r' ($\bar\lambda='+f'{group.MeanLambda.iloc[0]:.3f}'+r'$)}}\\')
        for _,row in group.iterrows():
            lines.append(f'{display[row.Method]} & {row.Bias*1e6:.3f} & {row.Variance*1e11:.3f} & {row.RMSE*1e6:.3f}'+r'\\')
    lines += [r'\bottomrule',r'\end{tabular}']
    rendered='\n'.join(lines)+'\n'
    target=PAPER/'tables/regime_comparison_table.tex'
    assert rendered==target.read_text(),'Table 3 displayed values would change; inspect before writing.'
    target.write_text(rendered)

    rebuild_frequency()
    print('Table 3 unchanged; Supplement Table S1 rebuilt from recorded paths.')


def rebuild_frequency():
    freq=pd.read_csv(ROOT/'results/frequency/frequency_regenerated.csv')
    freq.to_csv(PAPER/'replication_sources/n_sensitivity_alg2_1_2_10_per_sec.csv',index=False)
    lines=[r'\begin{tabular}{cccccc}',r'\toprule',
           r'$\lambda$ & $n$ & Obs./sec. & $P(\widehat s_C=s^\star)$ & Mean $\mathrm{CR}_n$ & 95\% coverage \\',r'\midrule']
    for index,target in enumerate(design.TARGETS):
        if index:lines.append(r'\addlinespace')
        for j,(_,row) in enumerate(freq[freq.Lambda==target].iterrows()):
            lam=f'{target:.3f}' if j==0 else ''
            lines.append(f'{lam} & {int(row.N):,} & {int(row.ObsPerSecond)} & {row.PhaseRate:.4f} & {row.MeanCR:.4f} & {row.Coverage:.4f}'+r' \\')
    lines += [r'\bottomrule',r'\end{tabular}']
    (PAPER/'tables/sampling_frequency.tex').write_text('\n'.join(lines)+'\n')


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--frequency-only',action='store_true',help='Rebuild Supplement Table S1 without touching Table 3.')
    args=parser.parse_args()
    if args.frequency_only:
        summarize_frequency()
        rebuild_frequency()
    else:
        build()
