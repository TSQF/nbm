# Current numerical table sources

All main-paper cells use n=234000 and 10000 replications. Tables 1 and 2 use fixed lambda targets .171/.631/.998. Table 3 retains the original random Heston environments, whose rounded mean pathwise shape indices motivate these controlled targets without identifying the two data-generating processes.

- `table1_panelA_pilot_phase_alg2_theta05.csv`: s_p=2,3,4 with theta_p=.05.
- `table1_panelB_pilot_scale_alg2.csv`: theta_p=.03,.05,.07 with s_p=3. Its `N` column is the replication count.
- `table2_alg2_design_inference_theta05.csv`: criterion ratios and empirical nominal-interval coverage, pilot (3,.05).
- `table3_alg2_bias_variance_rmse_theta05.csv`: unchanged complete-estimator comparisons.
- `n_sensitivity_alg2_1_2_10_per_sec.csv`: the same new targets at n=23400,46800,234000; high-frequency rows reuse Table 2.

The direct plug-in estimator uses the estimated shape index for phase selection and the closed-form nuisance-based scale. The 121-point logarithmic grid is solely the ex post executable CR reference.

Shape/seed pairs are (.171,3657603516), (.631,575453803), (.998,3123275394), using PCG64 and batches of 40. Within each target, both Table 1 panels and Table 2 share observations. `../replication_table1/` contains the controlled driver, full path outputs and validation; `../replication_full/` contains the complete Table 3 and sampling-frequency workflows. Former targets are retained in explicitly superseded directories. `CLEAN91_NUMERICAL_SOURCE_MANIFEST.csv` is a legacy filename for the current source hashes.
