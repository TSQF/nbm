"""Diagnose existing Table 2 paths without changing the estimator or manuscript tables.

Oracle nuisance substitutions are infeasible diagnostics. The log interval is an
exploratory comparison on the same paths, not an independently validated revision.
"""
from pathlib import Path
import hashlib
import json
import sys

import numpy as np
import pandas as pd
from scipy.stats import kurtosis, norm, skew

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'code'))
from nbm_iid_finite_grid import _studentizing_avar
from controlled_design import TARGETS,T23,T34


def run():
    critical = float(norm.ppf(.975))
    rows = []
    inputs = {}
    for target in TARGETS:
        stem = ROOT / 'results' / f'common_lambda_{target:.3f}'
        npz = Path(str(stem) + '.npz')
        meta = json.loads(Path(str(stem) + '.json').read_text())
        arrays = np.load(npz)
        base = arrays['baseline_pilot_estimate_inference']
        design = arrays['sp3_theta0.05']
        iv, iq, n = meta['true_iv'], meta['true_iq'], meta['n']
        count = len(base)
        phase, width = design[:, 1].astype(int), design[:, 3].astype(int)
        estimate = base[:, 3]
        error = estimate - iv
        se = n**(-.25) * np.sqrt(base[:, 4])
        z = error / se
        np.testing.assert_allclose(z, base[:, 5], rtol=1e-14, atol=1e-14)
        original = np.abs(z) <= critical
        np.testing.assert_array_equal(original, base[:, 6].astype(bool))
        av_oracle = _studentizing_avar(phase, width, n, np.full(count, iv),
                                      np.full(count, iq), np.full(count, .0005**2))
        av_iq = _studentizing_avar(phase, width, n, base[:, 0],
                                  np.full(count, iq), base[:, 2])
        z_oracle = error / (n**(-.25) * np.sqrt(av_oracle))
        z_iq = error / (n**(-.25) * np.sqrt(av_iq))
        covered_iq = np.abs(z_iq) <= critical
        assert np.all(estimate > 0), 'Log diagnostic needs positive estimates.'
        z_log = estimate * np.log(estimate / iv) / se
        paired_iq_gain = covered_iq.astype(float) - original.astype(float)
        covered_log = np.abs(z_log) <= critical
        paired_log_gain = covered_log.astype(float) - original.astype(float)
        oracle_phase = 2 if target < T23 else 3 if target < T34 else 4
        row = dict(
            lambda_target=target, replications=count, n=n,
            coverage_original=float(original.mean()),
            coverage_oracle_iq_only=float(covered_iq.mean()),
            coverage_oracle_all_nuisances=float(np.mean(np.abs(z_oracle) <= critical)),
            coverage_exploratory_log=float(covered_log.mean()),
            coverage_in_sample_mean_bias_removed=float(np.mean(np.abs((error-error.mean())/se) <= critical)),
            oracle_iq_paired_gain_mcse=float(paired_iq_gain.std(ddof=1)/np.sqrt(count)),
            exploratory_log_paired_gain_mcse=float(paired_log_gain.std(ddof=1)/np.sqrt(count)),
            nominal_coverage_mcse=float(np.sqrt(.95*.05/count)),
            observed_coverage_mcse=float(np.sqrt(original.mean()*(1-original.mean())/count)),
            z_mean=float(z.mean()), z_variance=float(z.var(ddof=1)),
            z_skewness=float(skew(z, bias=False)), z_excess_kurtosis=float(kurtosis(z, bias=False)),
            lower_tail_rate=float(np.mean(z < -critical)), upper_tail_rate=float(np.mean(z > critical)),
            z_q025=float(np.quantile(z,.025)), z_q975=float(np.quantile(z,.975)),
            oracle_iq_z_mean=float(z_iq.mean()), oracle_iq_z_variance=float(z_iq.var(ddof=1)),
            estimator_bias=float(error.mean()), estimator_sd=float(error.std(ddof=1)),
            bias_to_sd_ratio=float(error.mean()/error.std(ddof=1)),
            mean_se=float(se.mean()), rms_se=float(np.sqrt(np.mean(se**2))),
            error_se_correlation=float(np.corrcoef(error,se)[0,1]),
            pilot_iq_ratio_mean=float(np.mean(base[:,1]/iq)),
            pilot_iq_ratio_q025=float(np.quantile(base[:,1]/iq,.025)),
            pilot_iq_ratio_median=float(np.quantile(base[:,1]/iq,.5)),
            pilot_iq_ratio_q975=float(np.quantile(base[:,1]/iq,.975)),
            pilot_avar_to_oracle_mean=float(np.mean(base[:,4]/av_oracle)),
            oracle_phase_selection_rate=float(np.mean(phase == oracle_phase)),
            mean_selected_width=float(width.mean()),
        )
        rows.append(row)
        inputs[npz.name] = hashlib.sha256(npz.read_bytes()).hexdigest()
    result = dict(
        description='Read-only diagnostic of retained common-path Table 2 outputs.',
        fresh_simulation=False, manuscript_results_changed=False,
        oracle_substitutions_feasible=False,
        oracle_scope='Only nuisance inputs of standard errors replaced; original random design and final estimate held fixed.',
        exploratory_log_interval='[estimate*exp(-1.959963984540054*se/estimate), estimate*exp(1.959963984540054*se/estimate)]',
        independent_validation_of_log_interval=False,
        fitted_bias_correction_feasible=False,
        inputs_sha256=inputs, results=rows,
    )
    out=ROOT/'diagnostics'
    out.mkdir(exist_ok=True)
    (out/'table2_coverage_diagnostics.json').write_text(json.dumps(result,indent=2)+'\n')
    pd.DataFrame(rows).to_csv(out/'table2_coverage_diagnostics.csv',index=False)
    print(pd.DataFrame(rows)[['lambda_target','coverage_original','coverage_oracle_iq_only',
                            'coverage_oracle_all_nuisances','coverage_exploratory_log']].to_string(index=False))


if __name__ == '__main__':
    run()
