# Tables 1 and 2: common-path controlled experiment

The adopted shape targets are lambda = 0.171, 0.631 and 0.998. Both Table 1 panels and Table 2 use the same observations within each target. Each target has n=234000, 10000 replications and batches of 40.

## Streams and implementation

Shape/seed pairs are (.171,3657603516), (.631,575453803), (.998,3123275394). NumPy PCG64 draws latent increments first and observation noise second. The five pilot settings are (2,.05), (3,.05), (4,.05), (3,.03), (3,.07); (3,.05) supplies the shared baseline. These seeds preserve the old .15/.60/.97 standard-normal and noise streams while changing the deterministic variance shape.

The final selector uses direct phase thresholds and the closed-form scale, clipped to [.01,.20] and rounded to an integer width. The 121-point grid is only the ex post CR reference. The historical `N` column in Table 1 CSV summaries denotes 10000 replications.

## Reproduce

Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0 and pandas 2.2.3 were used. Run:

```bash
python run_common_paths.py --target .171
python run_common_paths.py --target .631
python run_common_paths.py --target .998
python validate_and_build_tables.py
```

The validator checks all shared numerical fields against the adopted source CSV files, checks phase counts exactly, verifies unchanged design/DGP function bodies, and rebuilds both Table 1 panels and Table 2. `VALIDATION.json` records the checks. Per-path NPZ arrays and JSON stream metadata are in `results/`.

`original/` retains the historical producer and superseded .15/.60/.97 results. The superseded historical Panel B CSV remains an audit record only; it is not an input to current tables. `diagnostics/adopted_lambda_trial/` records the independent audit of the adopted trial results. Table 3 and the theory are unchanged.

Run `python diagnose_table2_coverage.py` for saved-path coverage diagnostics. True-nuisance substitutions and log intervals are infeasible or exploratory diagnostics, not changes to the reported algorithm. The legacy `nbm_iid_finite_grid.py` filename remains because the active driver imports shared estimation and variance functions from it.
