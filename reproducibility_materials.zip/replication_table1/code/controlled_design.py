"""Archived theta05 controlled-design functions, with portable imports.

Function bodies are copied unchanged from run_theta05_controlled.py.
"""
import math
import numpy as np
from scipy.optimize import brentq
from common import OMEGA
from verify_nested_manuscript_theory import asymptotic_coefficients
N=234_000
NSIM=10_000
BATCH=40
TARGETS=(0.171,0.631,0.998)
TARGET_IV=0.04/252
DELTA=1e-4
SEEDS={0.171:3657603516,0.631:575453803,0.998:3123275394}
T23=0.214428329551
T34=0.894738052767
LOWER=.01
UPPER=.20


def shape_lambda(w):
    t=(np.arange(60000)+.5)/60000; f=DELTA+np.exp(-.5*((t-.5)/w)**2)
    return float(f.mean()/np.sqrt(np.mean(f*f)))

def solve_width(target):
    return math.exp(brentq(lambda x:shape_lambda(math.exp(x))-target,math.log(5e-4),math.log(2),xtol=1e-13))

def rho_for(target):
    w=solve_width(target); t=(np.arange(N)+.5)/N; f=DELTA+np.exp(-.5*((t-.5)/w)**2)
    return TARGET_IV/f.mean()*f

def alg2_design(iv,iq,om):
    lam=iv/np.sqrt(iq)
    s=np.full(len(iv),4,dtype=np.int64); s[lam<T34]=3; s[lam<T23]=2
    theta=np.empty(len(iv),dtype=float)
    for q in (2,3,4):
        mask=s==q
        if not np.any(mask): continue
        a,b,c=asymptotic_coefficients(q)
        th2=om[mask]*(b*iv[mask]+np.sqrt(b*b*iv[mask]*iv[mask]+12*a*c*iq[mask]))/(2*a*iq[mask])
        theta[mask]=np.sqrt(th2)
    theta=np.clip(theta,LOWER,UPPER)
    m=np.rint(theta*math.sqrt(N)).astype(np.int64)
    return lam,s,theta,m

def simulate(rng,rho,b):
    inc=rng.standard_normal((b,N)); inc*=np.sqrt(rho/N)[None,:]
    x=np.empty((b,N+1)); x[:,0]=0; np.cumsum(inc,axis=1,out=x[:,1:]); x+=rng.normal(0,OMEGA,size=x.shape)
    return x
