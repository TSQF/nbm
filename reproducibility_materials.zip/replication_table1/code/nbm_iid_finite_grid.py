"""Theorem-aligned iid NBM inference on a prespecified deterministic theta grid.

This module implements the same-sample finite-grid procedure proved in the
revised manuscript.  It is intentionally narrower than ``nbm_feasible.py``:

* iid observation noise only;
* phases {2,3,4};
* no adaptive overlap selection (stride equals block width m);
* a user-supplied deterministic grid Theta_G fixed before seeing the data;
* deterministic positivity floors that vanish with n by default.

The broader ``fit_nbm`` routine remains useful as an empirical/continuous
implementation, but its data-dependent integer-window search is not the object
of the manuscript's formal finite-grid studentized CLT.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from statistics import NormalDist
from typing import Iterable

import numpy as np

from verify_nested_manuscript_theory import asymptotic_coefficients


PHASES = (2, 3, 4)


@dataclass(frozen=True)
class IIDFiniteGridFit:
    estimate: np.ndarray
    standard_error: np.ndarray
    ci_lower: np.ndarray
    ci_upper: np.ndarray
    asymptotic_variance: np.ndarray
    selected_phase: np.ndarray
    selected_grid_index: np.ndarray
    selected_theta_grid: np.ndarray
    selected_block: np.ndarray
    pilot_iv: np.ndarray
    pilot_iq: np.ndarray
    pilot_omega2: np.ndarray
    pilot_points: int
    pilot_block: int
    theta_grid: np.ndarray
    positivity_floors: tuple[float, float, float]


def logarithmic_theta_grid(lower: float, upper: float, k: int) -> np.ndarray:
    """Return a deterministic logarithmic grid on [lower, upper]."""
    if not (0.0 < lower < upper):
        raise ValueError("require 0 < lower < upper")
    if k < 2:
        raise ValueError("k must be at least 2")
    return lower * np.power(upper / lower, np.arange(k) / (k - 1.0))


def _as_price_matrix(prices: np.ndarray) -> np.ndarray:
    values = np.asarray(prices, dtype=np.float64)
    if values.ndim == 1:
        values = values[None, :]
    if values.ndim != 2 or values.shape[1] < 3:
        raise ValueError("prices must have shape (n_paths,n_prices) or (n_prices,)")
    if not np.all(np.isfinite(values)):
        raise ValueError("prices contain non-finite values")
    return values


def _default_floors(n_returns: int) -> tuple[float, float, float]:
    """Concrete deterministic vanishing floors for the reference implementation.

    Prices are log prices and hence dimensionless in the manuscript's setup.
    The sequences below are intentionally far below the benchmark signal/noise
    scales while satisfying the theorem's requirement that each floor vanish.
    """
    n = float(n_returns)
    return n ** -2, n ** -3, n ** -3



def _preaveraging_quarticity(
    prices: np.ndarray,
    n_returns: int,
    iv_floor_source: np.ndarray,
    eta_iq: float,
    theta_q: float = 0.25,
    return_raw: bool = False,
):
    """Triangular pre-averaging quarticity pilot (Jacod et al., 2009, Remark 4).

    The weight is g(x)=min(x,1-x).  With Delta_n=1/n and
    k_q = round(theta_q*sqrt(n)), the estimator is the finite-sample
    variant of equation (3.14) described in Supplement S3: omit the last
    outer term in its first two sums and shift the inner raw-return window
    one return to the right. The supplement proves asymptotic equivalence.
    It is used only as a nuisance
    pilot for design selection and studentization; the NBM point estimator is
    unchanged.  The structural projection IQ >= IV^2 is imposed afterward.
    """
    theta_q = float(theta_q)
    if theta_q <= 0.0:
        raise ValueError("theta_q must be positive")
    k_q = max(4, int(np.rint(theta_q * math.sqrt(n_returns))))
    if 2 * k_q >= n_returns:
        raise ValueError("quarticity pre-averaging window is too long")

    returns = np.diff(prices, axis=1)
    # barY_i = sum_{j=1}^{k-1} g(j/k) Delta_{i+j}Y.  For the
    # triangular weight the moving weighted sum can be evaluated in O(n)
    # time from prefix sums, avoiding a long convolution at large n.
    n_windows = n_returns - k_q + 1
    prefix = np.concatenate(
        (np.zeros((prices.shape[0], 1), dtype=np.float64), np.cumsum(returns, axis=1)),
        axis=1,
    )
    return_index = np.arange(n_returns, dtype=np.float64)
    prefix_indexed = np.concatenate(
        (
            np.zeros((prices.shape[0], 1), dtype=np.float64),
            np.cumsum(returns * return_index[None, :], axis=1),
        ),
        axis=1,
    )
    starts = np.arange(n_windows, dtype=np.int64)
    half = k_q // 2
    # Left arm: j=1,...,floor(k/2), weight j/k.
    left_sum = prefix[:, starts + half] - prefix[:, starts]
    left_indexed = prefix_indexed[:, starts + half] - prefix_indexed[:, starts]
    left = (left_indexed - (starts - 1)[None, :] * left_sum) / k_q
    # Right arm: j=floor(k/2)+1,...,k-1, weight (k-j)/k.
    right_start = starts + half
    right_end = starts + k_q - 1
    right_sum = prefix[:, right_end] - prefix[:, right_start]
    right_indexed = prefix_indexed[:, right_end] - prefix_indexed[:, right_start]
    right = ((k_q + starts - 1)[None, :] * right_sum - right_indexed) / k_q
    preavg = left + right

    psi1 = 1.0
    psi2 = 1.0 / 12.0
    theta_eff = k_q / math.sqrt(n_returns)

    term1 = np.sum(np.power(preavg, 4), axis=1) / (
        3.0 * theta_eff**2 * psi2**2
    )

    sqret = np.square(returns)
    csum = np.concatenate(
        (np.zeros((prices.shape[0], 1), dtype=np.float64), np.cumsum(sqret, axis=1)),
        axis=1,
    )
    n_cross = n_returns - 2 * k_q + 1
    # For start i this is sum_{j=i+k+1}^{i+2k} (Delta_j Y)^2.
    # Return array entry j-1 represents Delta_j Y (Supplement S3).
    local_raw_qv = csum[:, 2 * k_q : 2 * k_q + n_cross] - csum[:, k_q : k_q + n_cross]
    term2 = (
        (1.0 / n_returns)
        * psi1
        / (theta_eff**4 * psi2**2)
        * np.sum(np.square(preavg[:, :n_cross]) * local_raw_qv, axis=1)
    )
    term3 = (
        (1.0 / n_returns)
        * psi1**2
        / (4.0 * theta_eff**4 * psi2**2)
        * np.sum(sqret[:, :-2] * sqret[:, 2:], axis=1)
    )
    iq_raw = term1 - term2 + term3
    iq = np.maximum.reduce(
        (iq_raw, np.square(iv_floor_source), np.full_like(iq_raw, float(eta_iq)))
    )
    return (iq, k_q, iq_raw) if return_raw else (iq, k_q)


def _pilot(
    prices: np.ndarray,
    n_returns: int,
    floors: tuple[float, float, float],
    pilot_power: float = 0.60,
    pilot_scale: float = 0.25,
    quarticity_theta: float = 0.25,
    diagnostics: dict | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, int, int]:
    """Same-sample hybrid pilot used by the revised finite-grid procedure.

    The IV component uses the sparse pseudo-sample, quarticity uses the full
    record, and the noise variance uses the full-sample return moment with an
    IV/n correction. The noise-variance estimate is root-n consistent under
    the manuscript's iid-noise assumptions.
    The quarticity structural projection is applied after bias correction.
    """
    p_returns = max(2, int(math.floor(n_returns ** float(pilot_power))))
    sparse_indices = np.floor(
        np.arange(p_returns + 1, dtype=np.float64) * n_returns / p_returns
    ).astype(int)
    if np.unique(sparse_indices).size != sparse_indices.size:
        raise RuntimeError("sparse pilot indices are not unique")
    sparse = prices[:, sparse_indices]
    pilot_l = max(2, int(math.floor(float(pilot_scale) * math.sqrt(p_returns))))

    # Sparse-record correction Q_{1,p} for the IV pilot.
    q1_sparse = np.square(np.diff(sparse, axis=1)).mean(axis=1)
    # Full-sample return moment for the noise-variance pilot. Under iid
    # observation noise, Q_{1,n}=2 omega^2 + IV/n + O_p(n^{-1/2}).
    q1_full = np.square(np.diff(prices, axis=1)).mean(axis=1)

    # Phase-one nonoverlapping block-mean differences.
    block_count = sparse.shape[1] // pilot_l
    if block_count <= 1:
        raise ValueError("pilot block width leaves fewer than two complete blocks")
    used = block_count * pilot_l
    block_means = sparse[:, :used].reshape(
        sparse.shape[0], block_count, pilot_l
    ).mean(axis=2)
    local = np.diff(block_means, axis=1)
    n_local = local.shape[1]
    r_value = np.square(local).mean(axis=1)

    a_l = pilot_l * (1.0 - 1.0 / 3.0) + 1.0 / (3.0 * pilot_l)
    d_l = pilot_l * a_l - 1.0
    nu = (pilot_l * r_value - q1_sparse) / d_l
    iv_raw = p_returns * nu
    # Bias-correct the full-sample moment by the sparse-pilot IV contribution.
    omega_raw = 0.5 * (q1_full - iv_raw / n_returns)

    eta_iv, eta_omega, eta_iq = map(float, floors)
    if min(eta_iv, eta_omega, eta_iq) <= 0.0:
        raise ValueError("positivity floors must be strictly positive")
    iv = np.maximum(iv_raw, eta_iv)
    omega2 = np.maximum(omega_raw, eta_omega)

    # Quarticity is estimated from the full record by the triangular
    # pre-averaging quarticity statistic of Jacod et al. (2009, Remark 4).
    # This is substantially more stable for sharply heterogeneous volatility
    # paths than the sparse fourth-power pilot used in revised22.
    iq, k_q, iq_raw = _preaveraging_quarticity(
        prices, n_returns, iv, eta_iq, theta_q=quarticity_theta, return_raw=True
    )
    if diagnostics is not None:
        diagnostics.update(RawIQ=iq_raw, PilotIV=iv, PilotIQ=iq, PilotOmega2=omega2,
            IQProjectionActive=(iq_raw < iv*iv) & (iv*iv >= eta_iq),
            QuarticityWindow=k_q)
    return iv, iq, omega2, p_returns, pilot_l


def _grid_design(
    pilot_iv: np.ndarray,
    pilot_iq: np.ndarray,
    pilot_omega2: np.ndarray,
    theta_grid: np.ndarray,
    n_returns: int,
    minimum_block: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    n_paths = pilot_iv.size
    best_risk = np.full(n_paths, np.inf)
    best_s = np.full(n_paths, PHASES[0], dtype=int)
    best_k = np.zeros(n_paths, dtype=int)
    best_m = np.ones(n_paths, dtype=int)

    # Strict updates with s and k traversed in increasing order implement the
    # manuscript's lexicographic min-argmin convention.
    for s_value in PHASES:
        a_value, b_value, c_value = asymptotic_coefficients(s_value)
        for k_value, theta in enumerate(theta_grid):
            m_value = int(np.rint(theta * math.sqrt(n_returns)))
            if m_value < minimum_block:
                continue
            block_count = (n_returns + 1) // m_value
            if block_count <= s_value:
                continue
            risk = (
                a_value * theta * pilot_iq
                + b_value * pilot_omega2 * pilot_iv / theta
                + c_value * np.square(pilot_omega2) / theta**3
            )
            update = risk < best_risk
            best_risk[update] = risk[update]
            best_s[update] = s_value
            best_k[update] = k_value
            best_m[update] = m_value

    if not np.all(np.isfinite(best_risk)):
        raise ValueError("theta grid contains no admissible design for some path")
    return best_s, best_k, best_m, best_risk


def _iid_nbm_for_random_design(
    prices: np.ndarray,
    n_returns: int,
    selected_s: np.ndarray,
    selected_m: np.ndarray,
) -> np.ndarray:
    q1 = np.square(np.diff(prices, axis=1)).mean(axis=1)
    result = np.empty(prices.shape[0], dtype=np.float64)
    pairs = np.column_stack((selected_s, selected_m))
    for pair in np.unique(pairs, axis=0):
        s_value, m_value = map(int, pair)
        mask = (selected_s == s_value) & (selected_m == m_value)
        subset = prices[mask]
        n_blocks = subset.shape[1] // m_value
        if n_blocks <= s_value:
            raise ValueError("selected block width leaves too few complete blocks")
        used = n_blocks * m_value
        block_means = subset[:, :used].reshape(
            subset.shape[0], n_blocks, m_value
        ).mean(axis=2)
        local = block_means[:, s_value:] - block_means[:, :-s_value]
        r_value = np.square(local).mean(axis=1)
        a_value = m_value * (s_value - 1.0 / 3.0) + 1.0 / (3.0 * m_value)
        denominator = m_value * a_value - 1.0
        result[mask] = n_returns * (
            m_value * r_value - q1[mask]
        ) / denominator
    return result


def _studentizing_avar(
    selected_s: np.ndarray,
    selected_m: np.ndarray,
    n_returns: int,
    pilot_iv: np.ndarray,
    pilot_iq: np.ndarray,
    pilot_omega2: np.ndarray,
) -> np.ndarray:
    theta_actual = selected_m / math.sqrt(n_returns)
    result = np.empty_like(theta_actual, dtype=np.float64)
    for s_value in PHASES:
        mask = selected_s == s_value
        a_value, b_value, c_value = asymptotic_coefficients(s_value)
        theta = theta_actual[mask]
        result[mask] = (
            a_value * theta * pilot_iq[mask]
            + b_value * pilot_omega2[mask] * pilot_iv[mask] / theta
            + c_value * np.square(pilot_omega2[mask]) / theta**3
        )
    return result


def fit_nbm_iid_finite_grid(
    prices: np.ndarray,
    *,
    theta_grid: Iterable[float],
    confidence_level: float = 0.95,
    positivity_floors: tuple[float, float, float] | None = None,
    minimum_block: int = 1,
    pilot_power: float = 0.60,
    pilot_scale: float = 0.25,
    quarticity_theta: float = 0.25,
) -> IIDFiniteGridFit:
    """Run the iid fixed-grid NBM confidence interval.

    Parameters
    ----------
    prices:
        One path `(n+1,)` or a batch `(n_paths,n+1)` of observed log prices.
    theta_grid:
        Prespecified deterministic positive window-ratio grid.  It must be
        chosen before inspecting the supplied data.
    confidence_level:
        Two-sided Wald confidence level.
    positivity_floors:
        `(eta_IV,n, eta_omega,n, eta_IQ,n)`.  If omitted, the reference
        implementation uses `(n^-2,n^-3,n^-3)`.
    minimum_block:
        Optional finite-sample lower bound on the rounded block width.  Any
        fixed value is asymptotically inactive because m is of order sqrt(n).
    """
    values = _as_price_matrix(prices)
    n_returns = values.shape[1] - 1
    if not 0.0 < confidence_level < 1.0:
        raise ValueError("confidence_level must lie in (0,1)")
    if minimum_block < 1:
        raise ValueError("minimum_block must be at least one")

    grid = np.asarray(tuple(float(x) for x in theta_grid), dtype=np.float64)
    if grid.ndim != 1 or grid.size == 0 or not np.all(np.isfinite(grid)):
        raise ValueError("theta_grid must be a nonempty finite one-dimensional grid")
    if np.any(grid <= 0.0):
        raise ValueError("theta_grid must be strictly positive")
    grid = np.unique(grid)

    floors = _default_floors(n_returns) if positivity_floors is None else positivity_floors
    pilot_iv, pilot_iq, pilot_omega2, p_returns, pilot_l = _pilot(
        values, n_returns, floors, pilot_power=pilot_power, pilot_scale=pilot_scale, quarticity_theta=quarticity_theta
    )
    selected_s, selected_k, selected_m, _ = _grid_design(
        pilot_iv, pilot_iq, pilot_omega2, grid, n_returns, minimum_block
    )
    estimate = _iid_nbm_for_random_design(values, n_returns, selected_s, selected_m)
    avar = _studentizing_avar(
        selected_s, selected_m, n_returns, pilot_iv, pilot_iq, pilot_omega2
    )
    se = n_returns ** (-0.25) * np.sqrt(np.maximum(avar, 0.0))
    critical = NormalDist().inv_cdf((1.0 + confidence_level) / 2.0)

    return IIDFiniteGridFit(
        estimate=estimate,
        standard_error=se,
        ci_lower=estimate - critical * se,
        ci_upper=estimate + critical * se,
        asymptotic_variance=avar,
        selected_phase=selected_s,
        selected_grid_index=selected_k,
        selected_theta_grid=grid[selected_k],
        selected_block=selected_m,
        pilot_iv=pilot_iv,
        pilot_iq=pilot_iq,
        pilot_omega2=pilot_omega2,
        pilot_points=p_returns,
        pilot_block=pilot_l,
        theta_grid=grid,
        positivity_floors=tuple(map(float, floors)),
    )


def fit_nbm_iid_fixed_phase(
    prices: np.ndarray,
    *,
    phase: int,
    theta_grid: Iterable[float],
    confidence_level: float = 0.95,
    positivity_floors: tuple[float, float, float] | None = None,
    minimum_block: int = 1,
    pilot_power: float = 0.60,
    pilot_scale: float = 0.25,
    quarticity_theta: float = 0.25,
) -> IIDFiniteGridFit:
    """Run the same finite-grid procedure with the phase fixed in advance.

    This is a diagnostic comparator for the adaptive phase rule.  It uses
    exactly the same nuisance pilot, deterministic theta grid, rounding rule,
    estimator, and studentization as :func:`fit_nbm_iid_finite_grid`, but
    minimizes the plug-in first-order variance criterion only over the scale
    coordinate for a prespecified phase.
    """
    if int(phase) not in PHASES:
        raise ValueError(f"phase must be one of {PHASES}")
    values = _as_price_matrix(prices)
    n_returns = values.shape[1] - 1
    if not 0.0 < confidence_level < 1.0:
        raise ValueError("confidence_level must lie in (0,1)")
    if minimum_block < 1:
        raise ValueError("minimum_block must be at least one")

    grid = np.asarray(tuple(float(x) for x in theta_grid), dtype=np.float64)
    if grid.ndim != 1 or grid.size == 0 or not np.all(np.isfinite(grid)):
        raise ValueError("theta_grid must be a nonempty finite one-dimensional grid")
    if np.any(grid <= 0.0):
        raise ValueError("theta_grid must be strictly positive")
    grid = np.unique(grid)

    floors = _default_floors(n_returns) if positivity_floors is None else positivity_floors
    pilot_iv, pilot_iq, pilot_omega2, p_returns, pilot_l = _pilot(
        values, n_returns, floors, pilot_power=pilot_power, pilot_scale=pilot_scale, quarticity_theta=quarticity_theta
    )
    a_value, b_value, c_value = asymptotic_coefficients(int(phase))
    best_risk = np.full(values.shape[0], np.inf)
    best_k = np.zeros(values.shape[0], dtype=int)
    best_m = np.ones(values.shape[0], dtype=int)
    for k_value, theta in enumerate(grid):
        m_value = int(np.rint(theta * math.sqrt(n_returns)))
        if m_value < minimum_block:
            continue
        block_count = (n_returns + 1) // m_value
        if block_count <= int(phase):
            continue
        risk = (
            a_value * theta * pilot_iq
            + b_value * pilot_omega2 * pilot_iv / theta
            + c_value * np.square(pilot_omega2) / theta**3
        )
        update = risk < best_risk
        best_risk[update] = risk[update]
        best_k[update] = k_value
        best_m[update] = m_value
    if not np.all(np.isfinite(best_risk)):
        raise ValueError("theta grid contains no admissible fixed-phase design")

    selected_s = np.full(values.shape[0], int(phase), dtype=int)
    estimate = _iid_nbm_for_random_design(values, n_returns, selected_s, best_m)
    avar = _studentizing_avar(
        selected_s, best_m, n_returns, pilot_iv, pilot_iq, pilot_omega2
    )
    se = n_returns ** (-0.25) * np.sqrt(np.maximum(avar, 0.0))
    critical = NormalDist().inv_cdf((1.0 + confidence_level) / 2.0)
    return IIDFiniteGridFit(
        estimate=estimate,
        standard_error=se,
        ci_lower=estimate - critical * se,
        ci_upper=estimate + critical * se,
        asymptotic_variance=avar,
        selected_phase=selected_s,
        selected_grid_index=best_k,
        selected_theta_grid=grid[best_k],
        selected_block=best_m,
        pilot_iv=pilot_iv,
        pilot_iq=pilot_iq,
        pilot_omega2=pilot_omega2,
        pilot_points=p_returns,
        pilot_block=pilot_l,
        theta_grid=grid,
        positivity_floors=tuple(map(float, floors)),
    )
