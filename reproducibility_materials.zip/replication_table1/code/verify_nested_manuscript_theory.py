"""Numerical checks for nested_manuscript_2026-08-08.tex.

The checks deliberately reconstruct the covariance coefficients from the
underlying trapezoid and block-noise weights instead of calling the Monte Carlo
estimator implementation.  This makes the script a useful guard against an
algebraic or transcription error in the manuscript.
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent


def trapezoid_weights(m: int, s: int) -> np.ndarray:
    """Weights of D_{q,m,s} on efficient one-step returns."""
    length = s * m + m - 1
    r = np.arange(1, length + 1, dtype=float)
    weights = np.zeros(length, dtype=float)
    weights[r <= m] = r[r <= m] / m
    plateau = (r > m) & (r <= s * m)
    weights[plateau] = 1.0
    falling = (r > s * m) & (r < s * m + m)
    weights[falling] = (s * m + m - r[falling]) / m
    return weights


def price_noise_weights(m: int, s: int) -> np.ndarray:
    """Weights of D_{q,m,s} on price-noise levels epsilon_i."""
    weights = np.zeros((s + 1) * m, dtype=float)
    weights[:m] = -1.0 / m
    weights[s * m : (s + 1) * m] = 1.0 / m
    return weights


def shifted_inner(left: np.ndarray, right: np.ndarray, shift: int) -> float:
    """Inner product of left[j] and right[j-shift], with zero padding."""
    if shift >= left.size or shift >= right.size:
        return 0.0
    length = min(left.size - shift, right.size)
    return float(np.dot(left[shift : shift + length], right[:length]))


def a_coefficient(m: int, s: int) -> float:
    return m * (s - 1.0 / 3.0) + 1.0 / (3.0 * m)


def theoretical_gamma_parts(m: int, s: int, h: int) -> tuple[float, float]:
    """Signal coefficient of nu and noise coefficient of omega^2."""
    if h == 0:
        return a_coefficient(m, s), 2.0 / m
    if 1 <= h < s:
        return m * (s - h), 0.0
    if h == s:
        return (m * m - 1.0) / (6.0 * m), -1.0 / m
    return 0.0, 0.0


def check_exact_covariances() -> None:
    for m in range(1, 13):
        for s in range(1, 9):
            signal = trapezoid_weights(m, s)
            noise = price_noise_weights(m, s)
            for h in range(0, s + 3):
                shift = h * m
                direct_signal = shifted_inner(signal, signal, shift)
                direct_noise = shifted_inner(noise, noise, shift)
                theory_signal, theory_noise = theoretical_gamma_parts(m, s, h)
                assert math.isclose(
                    direct_signal, theory_signal, rel_tol=1e-12, abs_tol=1e-12
                ), (m, s, h, direct_signal, theory_signal)
                assert math.isclose(
                    direct_noise, theory_noise, rel_tol=1e-12, abs_tol=1e-12
                ), (m, s, h, direct_noise, theory_noise)


def noise_autocovariance_from_ma(coefficients: np.ndarray) -> np.ndarray:
    """Autocovariances of a finite moving-average price-noise process."""
    order = coefficients.size - 1
    return np.array(
        [np.dot(coefficients[: coefficients.size - h], coefficients[h:])
         for h in range(order + 1)],
        dtype=float,
    )


def noise_return_autocovariances(gamma: np.ndarray) -> np.ndarray:
    """Autocovariances of Delta epsilon through lag R+1."""
    order = gamma.size - 1
    padded = np.pad(gamma, (0, 2))
    return np.array(
        [2.0 * padded[h] - padded[abs(h - 1)] - padded[h + 1]
         for h in range(order + 2)],
        dtype=float,
    )


def lag_quadratic_matrix(n: int, lag: int) -> np.ndarray:
    """B_h such that r' B_h r is the sample lag-h covariance."""
    if lag == 0:
        return np.eye(n) / n
    matrix = np.zeros((n, n), dtype=float)
    weight = 1.0 / (2.0 * (n - lag))
    indices = np.arange(n - lag)
    matrix[indices + lag, indices] = weight
    matrix[indices, indices + lag] = weight
    return matrix


def nested_quadratic_matrix(n: int, m: int, s: int) -> np.ndarray:
    """A_{m,s} such that r' A_{m,s} r equals R_{m,s}."""
    block_count = (n + 1) // m
    local_count = block_count - s
    weights = trapezoid_weights(m, s)
    matrix = np.zeros((n, n), dtype=float)
    for q in range(local_count):
        vector = np.zeros(n, dtype=float)
        start = q * m
        vector[start : start + weights.size] = weights
        matrix += np.outer(vector, vector)
    return matrix / local_count


def check_correlated_noise_extension() -> None:
    """Check spectral identities, exact unbiasedness and Gaussian risk trace."""
    coefficients = np.array([1.0, 0.35, -0.20]) * 3.0e-4
    gamma = noise_autocovariance_from_ma(coefficients)
    delta = noise_return_autocovariances(gamma)
    order = gamma.size - 1
    lags = np.arange(1, order + 2, dtype=float)

    gamma0 = -float(np.dot(lags, delta[1:]))
    omega_lr = -float(np.dot(lags**2, delta[1:]))
    boundary = -float(np.dot(lags**3 - lags, delta[1:])) / 6.0
    assert math.isclose(gamma0, gamma[0], rel_tol=1e-13, abs_tol=1e-20)
    assert math.isclose(
        omega_lr, gamma[0] + 2.0 * gamma[1:].sum(),
        rel_tol=1e-13, abs_tol=1e-20,
    )
    assert math.isclose(
        boundary, np.dot(np.arange(1, order + 1), gamma[1:]),
        rel_tol=1e-13, abs_tol=1e-20,
    )

    n = 96
    m = 8
    nu = 2.5e-6
    return_cov = np.zeros(n)
    return_cov[: delta.size] = delta
    return_cov[0] += nu
    sigma = np.fromfunction(
        lambda i, j: return_cov[np.abs(i - j).astype(int)], (n, n), dtype=int
    )

    for s in range(1, 5):
        a_value = a_coefficient(m, s)
        d_value = m * a_value - 1.0
        nested = nested_quadratic_matrix(n, m, s)
        correction = lag_quadratic_matrix(n, 0)
        chi_s = 6.0 if s == 1 else 4.0
        for h in range(1, order + 2):
            coefficient = (
                -2.0 * (h * h - 1.0)
                + chi_s * (h**3 - h) / (6.0 * m)
            )
            correction += coefficient * lag_quadratic_matrix(n, h)

        estimator_matrix = n / d_value * (m * nested - correction)
        exact_mean = float(np.trace(estimator_matrix @ sigma))
        exact_variance = 2.0 * float(
            np.trace(estimator_matrix @ sigma @ estimator_matrix @ sigma)
        )
        assert math.isclose(exact_mean, n * nu, rel_tol=2e-12, abs_tol=1e-15)
        assert exact_variance > 0.0

    print("Correlated-noise spectral correction: PASS")


def check_jump_truncation_geometry() -> None:
    """Check the finite-window contamination count used in the jump proof."""
    for m in range(1, 20):
        for s in range(1, 9):
            weights = trapezoid_weights(m, s)
            n = 20 * m
            block_count = (n + 1) // m
            local_count = block_count - s
            for return_index in range(1, n + 1):
                affected = 0
                for q in range(local_count):
                    relative = return_index - q * m
                    if 1 <= relative <= weights.size:
                        affected += 1
                assert affected <= s + 1, (m, s, return_index, affected)

    for moment_delta in (0.01, 0.5, 2.0, 8.0):
        upper = (6.0 + moment_delta) / (4.0 * (8.0 + moment_delta))
        assert upper > 1.0 / 8.0
        exponent = 0.5 - (8.0 + moment_delta) / 4.0
        exponent += (8.0 + moment_delta) * (0.5 * (1.0 / 8.0 + upper))
        assert exponent < 0.0

    print("Finite-activity jump truncation geometry: PASS")


def asymptotic_coefficients(s: int) -> tuple[float, float, float]:
    c = s - 1.0 / 3.0
    a_value = (4.0 * s**3 - 2.0 * s + 1.0) / (3.0 * c**2)
    b_value = (8.0 * s - 4.0) / c**2
    c_value = 12.0 / c**2
    return a_value, b_value, c_value


def continuous_kernel_segments(
    s: int, *, price_noise: bool = False
) -> list[tuple[float, float, float, float]]:
    """Piecewise-linear segments (left, right, slope, intercept)."""
    if price_noise:
        return [(0.0, 1.0, 0.0, -1.0),
                (float(s), float(s + 1), 0.0, 1.0)]

    segments = [(0.0, 1.0, 1.0, 0.0)]
    if s > 1:
        segments.append((1.0, float(s), 0.0, 1.0))
    segments.append((float(s), float(s + 1), -1.0, float(s + 1)))
    return segments


def continuous_kernel_correlation(
    segments: list[tuple[float, float, float, float]], z: float
) -> float:
    """Integral of k(u) k(u+z) du, evaluated analytically by segments."""
    total = 0.0
    for left, right, slope, intercept in segments:
        for shifted_left, shifted_right, shifted_slope, shifted_intercept in segments:
            lower = max(left, shifted_left - z)
            upper = min(right, shifted_right - z)
            if lower >= upper:
                continue
            shifted_constant = shifted_slope * z + shifted_intercept
            quadratic = slope * shifted_slope
            linear = slope * shifted_constant + intercept * shifted_slope
            constant = intercept * shifted_constant
            total += quadratic * (upper**3 - lower**3) / 3.0
            total += linear * (upper**2 - lower**2) / 2.0
            total += constant * (upper - lower)
    return total


def overlap_coefficients(s: int, alpha: float) -> tuple[float, float, float]:
    """AVAR coefficients when local windows move by alpha times the block width."""
    assert 0.0 < alpha <= 1.0
    signal = continuous_kernel_segments(s)
    noise = continuous_kernel_segments(s, price_noise=True)
    c_value = s - 1.0 / 3.0
    signal_sum = 0.0
    cross_sum = 0.0
    noise_sum = 0.0
    maximum_lag = int(math.ceil((s + 1.0) / alpha))
    for j in range(maximum_lag + 1):
        z = j * alpha
        signal_correlation = continuous_kernel_correlation(signal, z)
        noise_correlation = continuous_kernel_correlation(noise, z)
        multiplicity = 1.0 if j == 0 else 2.0
        signal_sum += multiplicity * signal_correlation**2
        cross_sum += multiplicity * signal_correlation * noise_correlation
        noise_sum += multiplicity * noise_correlation**2
    return (
        2.0 * alpha * signal_sum / c_value**2,
        4.0 * alpha * cross_sum / c_value**2,
        2.0 * alpha * noise_sum / c_value**2,
    )


def fully_overlapping_coefficients(s: int) -> tuple[float, float, float]:
    """Closed-form alpha-down-to-zero limits of the three overlap coefficients."""
    if s == 1:
        return 151.0 / 70.0, 6.0, 12.0
    denominator = (3.0 * s - 1.0) ** 2
    return (
        3.0 * (140.0 * s**3 - 70.0 * s + 31.0) / (35.0 * denominator),
        36.0 * (10.0 * s - 7.0) / (5.0 * denominator),
        72.0 / denominator,
    )


def check_overlap_frontier_coefficients() -> None:
    """Check the nonoverlap endpoint and the fully-overlapping Riemann limit."""
    for s in range(1, 9):
        endpoint = overlap_coefficients(s, 1.0)
        original = asymptotic_coefficients(s)
        assert np.allclose(endpoint, original, rtol=2e-13, atol=2e-13), (
            s, endpoint, original
        )

        limiting = fully_overlapping_coefficients(s)
        fine_grid = overlap_coefficients(s, 1.0 / 400.0)
        assert np.allclose(fine_grid, limiting, rtol=2e-5, atol=2e-5), (
            s, fine_grid, limiting
        )

    print("Overlap endpoint and full-overlap limit: PASS")


def oracle_theta(
    s: int, iv: float, iq: float, omega2: float
) -> tuple[float, float]:
    a_value, b_value, c_value = asymptotic_coefficients(s)
    theta2 = omega2 * (
        b_value * iv
        + math.sqrt(b_value**2 * iv**2 + 12.0 * a_value * c_value * iq)
    ) / (2.0 * a_value * iq)
    theta = math.sqrt(theta2)
    avar = (
        a_value * theta * iq
        + b_value * omega2 * iv / theta
        + c_value * omega2**2 / theta**3
    )
    return theta, avar


def dimensionless_oracle(s: int, shape: float) -> tuple[float, float]:
    """Return x_s^* and min_x F_s(x; shape)."""
    a_value, b_value, c_value = asymptotic_coefficients(s)
    x2 = (
        b_value * shape
        + math.sqrt(b_value**2 * shape**2 + 12.0 * a_value * c_value)
    ) / (2.0 * a_value)
    x_value = math.sqrt(x2)
    risk = (
        a_value * x_value
        + b_value * shape / x_value
        + c_value / x_value**3
    )
    return x_value, risk


def bisection_phase_crossing(left_s: int, right_s: int) -> float:
    left = 0.0
    right = 1.0
    for _ in range(100):
        middle = (left + right) / 2.0
        left_difference = (
            dimensionless_oracle(left_s, left)[1]
            - dimensionless_oracle(right_s, left)[1]
        )
        middle_difference = (
            dimensionless_oracle(left_s, middle)[1]
            - dimensionless_oracle(right_s, middle)[1]
        )
        if left_difference * middle_difference <= 0.0:
            right = middle
        else:
            left = middle
    return (left + right) / 2.0


def check_global_phase_reduction() -> None:
    threshold_23 = bisection_phase_crossing(2, 3)
    threshold_34 = bisection_phase_crossing(3, 4)
    assert math.isclose(threshold_23, 0.214428329551, rel_tol=1e-11)
    assert math.isclose(threshold_34, 0.894738052767, rel_tol=1e-11)

    # Dense numerical guard for the analytic dominance proof in the manuscript.
    for shape in np.linspace(0.0, 1.0, 2001):
        risks = {
            s: dimensionless_oracle(s, float(shape))[1]
            for s in range(1, 101)
        }
        best_s = min(risks, key=risks.get)
        assert best_s in {2, 3, 4}
        assert risks[2] < risks[1]
        assert all(risks[s + 1] > risks[s] for s in range(4, 100))

    print()
    print("Global phase reduction: PASS")
    print(f"lambda_23 = {threshold_23:.12f}")
    print(f"lambda_34 = {threshold_34:.12f}")


def check_oracle_table() -> None:
    n = 23_400
    iv = 0.04 / 252.0
    iq = iv**2
    omega2 = 0.0005**2
    expected_theta = np.array(
        [0.114504, 0.0645784, 0.0462113, 0.0365570, 0.0305275, 0.0263702]
    )
    rows = []
    for s in range(1, 7):
        theta, avar = oracle_theta(s, iv, iq, omega2)
        rmse = math.sqrt(avar) / n**0.25
        rows.append((s, theta, theta * math.sqrt(n), s * theta * math.sqrt(n), rmse))
        assert math.isclose(theta, expected_theta[s - 1], rel_tol=2e-5)

    a_one, b_one, c_one = asymptotic_coefficients(1)
    assert math.isclose(a_one, 9.0 / 4.0)
    assert math.isclose(b_one, 9.0)
    assert math.isclose(c_one, 27.0)

    print("s   theta*      m*       K*       asymptotic RMSE")
    for row in rows:
        print(f"{row[0]:d}  {row[1]:.7f}  {row[2]:7.3f}  {row[3]:7.3f}  {row[4]:.9g}")


def check_saved_finite_oracle() -> None:
    # The saved Monte Carlo target below is tied to seed 20260728 and batch
    # size 100 in compare_nested_pbm_fs_zhang2005.py.  Because NumPy draws
    # batch-shaped arrays, changing the batch size changes the realized stream.
    grid = pd.read_csv(ROOT / "nested_pbm_fs_zhang2005_theory_grid.csv")
    best = grid.sort_values("IVRMSE").iloc[0]
    assert (int(best["K"]), int(best["L"]), int(best["m"])) == (21, 3, 7)
    assert math.isclose(float(best["IVRMSE"]), 7.8173482e-6, rel_tol=2e-7)

    mc = pd.read_csv(ROOT / "nested_pbm_fs_zhang2005_mc.csv")
    selected = mc[
        (mc["Parameter"] == "IV")
        & (mc["K"] == 21)
        & (mc["L"] == 3)
        & (mc["m"] == 7)
    ].iloc[0]
    assert math.isclose(float(selected["RMSE"]), 7.8661540e-6, rel_tol=2e-7)
    print()
    print("Finite Gaussian oracle: (s,m,K)=(3,7,21)")
    print(f"Exact-theory RMSE: {float(best['IVRMSE']):.9g}")
    print(f"Heston MC RMSE:    {float(selected['RMSE']):.9g}")


def main() -> None:
    check_exact_covariances()
    print("Exact covariance coefficients: PASS")
    check_correlated_noise_extension()
    check_jump_truncation_geometry()
    check_overlap_frontier_coefficients()
    check_oracle_table()
    check_global_phase_reduction()
    check_saved_finite_oracle()
    print()
    print("All manuscript checks passed.")


if __name__ == "__main__":
    main()
