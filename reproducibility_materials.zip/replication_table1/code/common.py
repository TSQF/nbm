from __future__ import annotations

import math
from pathlib import Path
import sys
from typing import Iterable

import numpy as np

HERE = Path(__file__).resolve().parent
PACKAGE = HERE.parents[1]
CODE = PACKAGE / 'replication' / 'code'
ADD_CODE = PACKAGE / 'replication' / 'additions' / 'code'
sys.path.insert(0, str(CODE))
sys.path.insert(0, str(ADD_CODE))

from nbm_iid_finite_grid import _default_floors  # noqa: E402
from verify_nested_manuscript_theory import asymptotic_coefficients  # noqa: E402

PILOT_PHASE = 4
# Closed-form phase-four scale evaluated at the reference nearly constant-volatility calibration.
PILOT_THETA = 0.0365570088992711
OMEGA = 0.0005
CRIT = 1.959963984540054


def pilot_width(n: int, minimum: int) -> int:
    return max(minimum, int(np.rint(PILOT_THETA * math.sqrt(n))))


def fixed_phase_pilot(
    prices: np.ndarray,
    n: int,
    *,
    phase: int = PILOT_PHASE,
    theta: float = PILOT_THETA,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Full-record fixed-phase NBM IV/IQ pilot with manuscript safeguards."""
    if prices.ndim != 2 or prices.shape[1] != n + 1:
        raise ValueError('prices must have shape (batch, n+1)')
    if phase < 1:
        raise ValueError('phase must be a positive integer')
    floors = tuple(map(float, _default_floors(n)))
    eta_iv, eta_om, eta_iq = floors

    k_iv = max(2, int(np.rint(theta * math.sqrt(n))))
    k_iq = max(4, int(np.rint(theta * math.sqrt(n))))
    q1 = np.square(np.diff(prices, axis=1)).mean(axis=1)

    b_iv = prices.shape[1] // k_iv
    if b_iv <= phase:
        raise ValueError('IV pilot leaves too few complete blocks')
    used_iv = b_iv * k_iv
    means_iv = prices[:, :used_iv].reshape(prices.shape[0], b_iv, k_iv).mean(axis=2)
    d_iv = means_iv[:, phase:] - means_iv[:, :-phase]
    r_iv = np.square(d_iv).mean(axis=1)
    a_iv = k_iv * (phase - 1.0 / 3.0) + 1.0 / (3.0 * k_iv)
    den_iv = k_iv * a_iv - 1.0
    iv_raw = n * (k_iv * r_iv - q1) / den_iv
    iv = np.maximum(iv_raw, eta_iv)

    om_raw = 0.5 * (q1 - iv_raw / n)
    om = np.maximum(om_raw, eta_om)

    b_iq = prices.shape[1] // k_iq
    n_q = b_iq - phase
    if n_q <= 0:
        raise ValueError('IQ pilot leaves too few block-mean differences')
    used_iq = b_iq * k_iq
    n_qn = used_iq - 1
    means_iq = prices[:, :used_iq].reshape(prices.shape[0], b_iq, k_iq).mean(axis=2)
    d_iq = means_iq[:, phase:] - means_iq[:, :-phase]
    sum4 = np.power(d_iq, 4).sum(axis=1)
    c_iq = phase - 1.0 / 3.0 + 1.0 / (3.0 * k_iq * k_iq)
    h_iq = k_iq / n_qn
    iq_raw = (
        sum4
        - (12.0 * c_iq / k_iq) * om * iv
        - (12.0 * n_q / (k_iq * k_iq)) * np.square(om)
    ) / (3.0 * c_iq * c_iq * h_iq)
    iq = np.maximum.reduce((iq_raw, np.square(iv), np.full_like(iv, eta_iq)))
    return iv, iq, om, iv_raw, iq_raw


def fixed_phase_design(
    iv: np.ndarray,
    iq: np.ndarray,
    om: np.ndarray,
    grid: np.ndarray,
    n: int,
    phase: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    a, b, c = asymptotic_coefficients(phase)
    best = np.full(len(iv), np.inf)
    index = np.zeros(len(iv), dtype=np.int64)
    width = np.ones(len(iv), dtype=np.int64)
    for j, theta in enumerate(grid):
        m = int(np.rint(theta * math.sqrt(n)))
        if m < 1 or (n + 1) // m <= phase:
            continue
        risk = a * theta * iq + b * om * iv / theta + c * np.square(om) / theta**3
        update = risk < best
        best[update] = risk[update]
        index[update] = j
        width[update] = m
    return index, width, best


def true_risk(
    phases: np.ndarray,
    theta: np.ndarray,
    iv: np.ndarray,
    iq: np.ndarray,
    omega2: float | np.ndarray = OMEGA**2,
) -> np.ndarray:
    phases = np.asarray(phases)
    theta = np.asarray(theta)
    omega2_arr = np.full(len(iv), float(omega2)) if np.isscalar(omega2) else np.asarray(omega2)
    out = np.empty(len(iv))
    for phase in (2, 3, 4):
        mask = phases == phase
        a, b, c = asymptotic_coefficients(phase)
        out[mask] = (
            a * theta[mask] * iq[mask]
            + b * omega2_arr[mask] * iv[mask] / theta[mask]
            + c * np.square(omega2_arr[mask]) / theta[mask] ** 3
        )
    return out


def executable_best_risk(iv: np.ndarray, iq: np.ndarray, grid: np.ndarray, n: int) -> np.ndarray:
    best = np.full(len(iv), np.inf)
    seen: set[tuple[int, int]] = set()
    omega2 = OMEGA**2
    for phase in (2, 3, 4):
        a, b, c = asymptotic_coefficients(phase)
        for theta_nominal in grid:
            m = int(np.rint(theta_nominal * math.sqrt(n)))
            if m < 1 or (n + 1) // m <= phase or (phase, m) in seen:
                continue
            seen.add((phase, m))
            theta_exec = m / math.sqrt(n)
            risk = a * theta_exec * iq + b * omega2 * iv / theta_exec + c * OMEGA**4 / theta_exec**3
            best = np.minimum(best, risk)
    return best


def criterion_ratio(
    phases: np.ndarray,
    widths: np.ndarray,
    iv: np.ndarray,
    iq: np.ndarray,
    grid: np.ndarray,
    n: int,
) -> np.ndarray:
    selected = true_risk(phases, widths / math.sqrt(n), iv, iq)
    return selected / executable_best_risk(iv, iq, grid, n)


def paired_rmse(est: np.ndarray, base: np.ndarray, truth: np.ndarray) -> dict[str, float]:
    loss_a = np.square(est - truth)
    loss_b = np.square(base - truth)
    rmse_a = math.sqrt(float(loss_a.mean()))
    rmse_b = math.sqrt(float(loss_b.mean()))
    influence = (loss_a - loss_a.mean()) / (2.0 * rmse_a) - (loss_b - loss_b.mean()) / (2.0 * rmse_b)
    se = float(influence.std(ddof=1) / math.sqrt(len(truth)))
    delta = rmse_a - rmse_b
    return {
        'DeltaRMSE': delta,
        'PairedMCSE': se,
        'CI95Low': delta - CRIT * se,
        'CI95High': delta + CRIT * se,
    }


def concat_npz(paths: Iterable[Path]) -> dict[str, np.ndarray]:
    packs: list[dict[str, np.ndarray]] = []
    for path in paths:
        with np.load(path) as z:
            packs.append({k: z[k] for k in z.files})
    if not packs:
        raise ValueError('no paths supplied')
    return {k: np.concatenate([p[k] for p in packs]) for k in packs[0]}
