"""Validate the adopted common-path Tables 1--2 and rebuild both Table 1 panels."""
from pathlib import Path
import ast, hashlib, json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
PAPER=ROOT.parent
TARGETS=(.171,.631,.998)
TOL=1e-14
keys=['Lambda','PilotPhase','PilotTheta']
all1=pd.concat([pd.read_csv(ROOT/'results'/f'common_lambda_{t:.3f}_table1.csv') for t in TARGETS],ignore_index=True)
all2=pd.concat([pd.read_csv(ROOT/'results'/f'common_lambda_{t:.3f}_table2.csv') for t in TARGETS],ignore_index=True)
refA=pd.read_csv(PAPER/'replication_sources/table1_panelA_pilot_phase_alg2_theta05.csv')
ref2=pd.read_csv(PAPER/'replication_sources/table2_alg2_design_inference_theta05.csv')
checks=[]
for label,ref,actual in [('PanelA',refA,all1[all1.PilotTheta==.05]),('Table2',ref2,all2)]:
    merged=ref.merge(actual,on=keys,validate='one_to_one',suffixes=('_retained','_rerun'))
    assert len(merged)==len(ref)
    for col in ref:
        if col in keys or col not in actual or not pd.api.types.is_numeric_dtype(ref[col]):continue
        error=np.abs(merged[col+'_retained']-merged[col+'_rerun'])
        checks.append(dict(source=label,column=col,cells=len(error),max_abs_error=float(error.max()),passed=bool((error<=TOL).all())))
assert all(r['passed'] for r in checks),checks

original=ast.parse((ROOT/'original/run_theta05_controlled.py').read_text())
derived=ast.parse((ROOT/'code/controlled_design.py').read_text())
functions=['shape_lambda','solve_width','rho_for','alg2_design','simulate']
def function_ast(tree,name):return ast.dump(next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name),include_attributes=False)
unchanged={name:function_ast(original,name)==function_ast(derived,name) for name in functions}
assert all(unchanged.values()),unchanged

# A single baseline array is shared by both panels and Table 2.
baseline=[]
for target in TARGETS:
    row=all1[(all1.Lambda==target)&(all1.PilotPhase==3)&(all1.PilotTheta==.05)].iloc[0]
    raw=np.load(ROOT/'results'/f'common_lambda_{target:.3f}.npz')['sp3_theta0.05']
    oracle=int(row.OraclePhase)
    probability=float(np.mean(raw[:,1]==oracle))
    assert probability==float(row.OraclePhaseSelectionRate)
    assert probability==float(refA[(refA.Lambda==target)&(refA.PilotPhase==3)].iloc[0].OraclePhaseSelectionRate)
    assert probability==float(ref2[ref2.Lambda==target].iloc[0].OraclePhaseSelectionRate)
    baseline.append(dict(target=target,correct=int(np.sum(raw[:,1]==oracle)),replications=len(raw),probability=probability,
        common_design_array_sha256=hashlib.sha256(raw.tobytes()).hexdigest()))

panelB=all1[all1.PilotPhase==3].sort_values(['Lambda','PilotTheta']).reset_index(drop=True)
csv=PAPER/'replication_sources/table1_panelB_pilot_scale_alg2.csv'
panelB.to_csv(csv,index=False)
table=PAPER/'tables/pilot_tuning_robustness.tex'
lines=[r'\begin{tabular}{lcccc}',r'\toprule',
       r'\multicolumn{5}{l}{\textit{Panel A. Sensitivity to preliminary phase, $\theta_p=0.05$}}\\',
       r'\addlinespace[2pt]',r'$\lambda$ & Continuous-scale phase & $s_p=2$ & $s_p=3$ & $s_p=4$\\',r'\midrule']
for target in TARGETS:
    rows=all1[(all1.Lambda==target)&(all1.PilotTheta==.05)].sort_values('PilotPhase')
    lines.append(f'{target:.3f} & {int(rows.iloc[0].OraclePhase)} & '+' & '.join(f'{v:.4f}' for v in rows.OraclePhaseSelectionRate)+r'\\')
lines += [r'\midrule',r'\multicolumn{5}{l}{\textit{Panel B. Sensitivity to preliminary scale, $s_p=3$}}\\',r'\addlinespace[2pt]',
       r'$\lambda$ & Statistic & $\theta_p=0.03$ & $\theta_p=0.05$ & $\theta_p=0.07$\\',r'\midrule']
for target in TARGETS:
    rows=panelB[panelB.Lambda==target].sort_values('PilotTheta')
    lines.append(f'{target:.3f} & '+r'$P(\widehat s=s^\star)$ & '+' & '.join(f'{v:.4f}' for v in rows.OraclePhaseSelectionRate)+r'\\')
    lines.append(r'      & Mean $\widehat\theta$      & '+' & '.join(f'{v:.5f}' for v in rows.MeanFinalTheta)+r'\\')
lines.extend([r'\bottomrule',r'\end{tabular}'])
table.write_text('\n'.join(lines)+'\n')
lines=[r'\begin{tabular}{cccc}',r'\toprule',r'$\lambda$ & Mean $\mathrm{CR}_n$ & $q_{.95}(\mathrm{CR}_n)$ & 95\% coverage\\',r'\midrule']
for _,row in all2.iterrows():
    lines.append(f'{row.Lambda:.3f} & {row.MeanCR:.4f} & {row.P95CR:.4f} & {row.Coverage95:.4f}'+r'\\')
lines.extend([r'\bottomrule',r'\end{tabular}'])
(PAPER/'tables/design_inference.tex').write_text('\n'.join(lines)+'\n')
pd.DataFrame(checks).to_csv(ROOT/'results/retained_results_validation.csv',index=False)
summary=dict(all_retained_results_passed=True,absolute_tolerance=TOL,numeric_cells_checked=sum(c['cells'] for c in checks),
    max_abs_error=max(c['max_abs_error'] for c in checks),original_design_function_bodies_unchanged=unchanged,
    shared_baselines=baseline,table2_all_numeric_columns_reproduced=True,
    panelA_and_panelB_regenerated_from_adopted_common_paths=True,adopted_targets=list(TARGETS),historical_panelB_generation_recovered=False)
(ROOT/'VALIDATION.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
print(panelB.to_string(index=False))
