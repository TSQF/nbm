from __future__ import annotations
import math, os, sys, time, json
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
os.environ.setdefault('OPENBLAS_NUM_THREADS','1'); os.environ.setdefault('OMP_NUM_THREADS','1'); os.environ.setdefault('MKL_NUM_THREADS','1')
import numpy as np, pandas as pd
from scipy.optimize import brentq

PKG=Path('/mnt/data/thetap05_compare/fullpkg/NBM_clean84_submission_package')
CODE=PKG/'replication'/'code'; ADD=PKG/'replication'/'additions'/'code'; PH=PKG/'replication'/'phase4_update'
sys.path.insert(0,str(CODE));sys.path.insert(0,str(ADD));sys.path.insert(0,str(PH))
from nbm_iid_finite_grid import _grid_design, _iid_nbm_for_random_design, _studentizing_avar, logarithmic_theta_grid
from verify_nested_manuscript_theory import asymptotic_coefficients
from common import CRIT, OMEGA, criterion_ratio, fixed_phase_pilot

N=234_000; NSIM=10_000; BATCH=40
TARGETS=(0.15,0.60,0.97); TARGET_IV=0.04/252; DELTA=1e-4
SEEDS={0.15:3657603516,0.60:575453803,0.97:3123275394}
SPS=(2,3,4); THETA_P=0.05
T23=0.214428329551; T34=0.894738052767
LOWER=.01; UPPER=.20; GRID=logarithmic_theta_grid(LOWER,UPPER,121)
OUT=Path('/mnt/data/thetap05_compare/results_controlled'); OUT.mkdir(parents=True,exist_ok=True)

def shape_lambda(w):
    t=(np.arange(60000)+.5)/60000; f=DELTA+np.exp(-.5*((t-.5)/w)**2)
    return float(f.mean()/np.sqrt(np.mean(f*f)))
def solve_width(target):
    return math.exp(brentq(lambda x:shape_lambda(math.exp(x))-target,math.log(5e-4),math.log(2),xtol=1e-13))
def rho_for(target):
    w=solve_width(target); t=(np.arange(N)+.5)/N; f=DELTA+np.exp(-.5*((t-.5)/w)**2)
    return TARGET_IV/f.mean()*f

def alg2_design(iv,iq,om):
    lam=iv/np.sqrt(iq)
    s=np.full(len(iv),4,dtype=np.int64); s[lam<T34]=3; s[lam<T23]=2
    theta=np.empty(len(iv),dtype=float)
    for q in (2,3,4):
        mask=s==q
        if not np.any(mask): continue
        a,b,c=asymptotic_coefficients(q)
        th2=om[mask]*(b*iv[mask]+np.sqrt(b*b*iv[mask]*iv[mask]+12*a*c*iq[mask]))/(2*a*iq[mask])
        theta[mask]=np.sqrt(th2)
    theta=np.clip(theta,LOWER,UPPER)
    m=np.rint(theta*math.sqrt(N)).astype(np.int64)
    return lam,s,theta,m

def simulate(rng,rho,b):
    inc=rng.standard_normal((b,N)); inc*=np.sqrt(rho/N)[None,:]
    x=np.empty((b,N+1)); x[:,0]=0; np.cumsum(inc,axis=1,out=x[:,1:]); x+=rng.normal(0,OMEGA,size=x.shape)
    return x

def run_target(target):
    out=OUT/f'theta05_lambda_{target:.3f}.npz'
    rho=rho_for(target); tiv=float(rho.mean()); tiq=float(np.mean(rho*rho)); rng=np.random.default_rng(SEEDS[target])
    # Table 1: both algorithms, all sp at common theta_p=0.05
    s1={sp:np.empty(NSIM,dtype=np.int8) for sp in SPS}; s2={sp:np.empty(NSIM,dtype=np.int8) for sp in SPS}
    # Table 2: reported pilot phase sp=3
    m1=np.empty(NSIM,dtype=np.int16); m2=np.empty(NSIM,dtype=np.int16)
    th2=np.empty(NSIM); est1=np.empty(NSIM); est2=np.empty(NSIM)
    cov1=np.empty(NSIM,dtype=bool); cov2=np.empty(NSIM,dtype=bool)
    z1=np.empty(NSIM); z2=np.empty(NSIM); cr1=np.empty(NSIM); cr2=np.empty(NSIM)
    piv3=np.empty(NSIM); piq3=np.empty(NSIM); pom3=np.empty(NSIM)
    t0=time.time()
    for st in range(0,NSIM,BATCH):
        cur=min(BATCH,NSIM-st); sl=slice(st,st+cur); y=simulate(rng,rho,cur)
        for sp in SPS:
            piv,piq,pom,_,_=fixed_phase_pilot(y,N,phase=sp,theta=THETA_P)
            aa1,_,mm1,_=_grid_design(piv,piq,pom,GRID,N,1)
            _,aa2,tt2,mm2=alg2_design(piv,piq,pom)
            s1[sp][sl]=aa1; s2[sp][sl]=aa2
            if sp==3:
                piv3[sl]=piv; piq3[sl]=piq; pom3[sl]=pom
                m1[sl]=mm1; m2[sl]=mm2; th2[sl]=tt2
                e1=_iid_nbm_for_random_design(y,N,aa1,mm1); e2=_iid_nbm_for_random_design(y,N,aa2,mm2)
                av1=_studentizing_avar(aa1,mm1,N,piv,piq,pom); av2=_studentizing_avar(aa2,mm2,N,piv,piq,pom)
                zz1=(e1-tiv)/(N**(-.25)*np.sqrt(av1)); zz2=(e2-tiv)/(N**(-.25)*np.sqrt(av2))
                est1[sl]=e1; est2[sl]=e2; z1[sl]=zz1; z2[sl]=zz2; cov1[sl]=np.abs(zz1)<=CRIT; cov2[sl]=np.abs(zz2)<=CRIT
                cr1[sl]=criterion_ratio(aa1,mm1,np.full(cur,tiv),np.full(cur,tiq),GRID,N)
                cr2[sl]=criterion_ratio(aa2,mm2,np.full(cur,tiv),np.full(cur,tiq),GRID,N)
        if (st+cur)%1000==0: print(json.dumps({'target':target,'done':st+cur,'elapsed':round(time.time()-t0,1)}),flush=True)
    np.savez_compressed(out,TrueIV=np.array([tiv]),TrueIQ=np.array([tiq]),PilotIV_sp3=piv3,PilotIQ_sp3=piq3,PilotOmega2_sp3=pom3,
                        Alg1M_sp3=m1,Alg2M_sp3=m2,Alg2Theta_sp3=th2,Alg1Estimate=est1,Alg2Estimate=est2,
                        Alg1Coverage=cov1,Alg2Coverage=cov2,Alg1Z=z1,Alg2Z=z2,Alg1CR=cr1,Alg2CR=cr2,
                        **{f'Alg1S_sp{sp}':s1[sp] for sp in SPS},**{f'Alg2S_sp{sp}':s2[sp] for sp in SPS})
    return str(out)

def summarize():
    rows1=[]; rows2=[]
    for target in TARGETS:
        oracle=2 if target<T23 else 3 if target<T34 else 4
        with np.load(OUT/f'theta05_lambda_{target:.3f}.npz') as z:
            for alg in ('Alg1','Alg2'):
                for sp in SPS:
                    s=z[f'{alg}S_sp{sp}']; cnt={q:float(np.mean(s==q)) for q in (2,3,4)}; modal=max(cnt,key=cnt.get)
                    rows1.append({'Algorithm':alg,'Lambda':target,'OraclePhase':oracle,'PilotPhase':sp,'PilotTheta':THETA_P,'PilotK':int(np.rint(THETA_P*math.sqrt(N))),
                                  'ModalFinalPhase':modal,'ModalFinalRate':cnt[modal],'OraclePhaseSelectionRate':float(np.mean(s==oracle)),
                                  'SelectS2':cnt[2],'SelectS3':cnt[3],'SelectS4':cnt[4]})
                est=z[f'{alg}Estimate']; cr=z[f'{alg}CR']; cov=z[f'{alg}Coverage']; zz=z[f'{alg}Z']; tiv=float(z['TrueIV'][0])
                s=z[f'{alg}S_sp3']; mm=z[f'{alg}M_sp3']; cnt={q:float(np.mean(s==q)) for q in (2,3,4)}; modal=max(cnt,key=cnt.get)
                row={'Algorithm':alg,'Lambda':target,'N':N,'Replications':NSIM,'PilotPhase':3,'PilotTheta':THETA_P,'PilotK':int(np.rint(THETA_P*math.sqrt(N))),
                     'ModalFinalPhase':modal,'ModalFinalRate':cnt[modal],'OraclePhaseSelectionRate':float(np.mean(s==oracle)),
                     'MeanCR':float(np.mean(cr)),'P95CR':float(np.quantile(cr,.95)),'Coverage95':float(np.mean(cov)),
                     'ZMean':float(np.mean(zz)),'ZVariance':float(np.var(zz,ddof=1)),'AdaptiveBias':float(np.mean(est-tiv)),
                     'AdaptiveVariance':float(np.var(est-tiv,ddof=1)),'AdaptiveRMSE':float(np.sqrt(np.mean((est-tiv)**2))),
                     'MeanFinalM':float(np.mean(mm)),'SelectS2':cnt[2],'SelectS3':cnt[3],'SelectS4':cnt[4]}
                if alg=='Alg2': row['MeanFinalTheta']=float(np.mean(z['Alg2Theta_sp3']))
                rows2.append(row)
    t1=pd.DataFrame(rows1); t2=pd.DataFrame(rows2)
    t1.to_csv(OUT/'theta05_table1_both_algorithms.csv',index=False); t2.to_csv(OUT/'theta05_table2_both_algorithms.csv',index=False)
    print('\nTABLE1\n',t1.to_string(index=False)); print('\nTABLE2\n',t2.to_string(index=False))

if __name__=='__main__':
    with ProcessPoolExecutor(max_workers=2) as ex:
        fs=[ex.submit(run_target,t) for t in TARGETS]
        for f in as_completed(fs): print('DONE',f.result(),flush=True)
    summarize()
