"""Regenerate both Table 1 panels and validate Table 2 on identical paths.

Every setting processes the same y within a batch. No estimator consumes RNG.
Example: python run_common_paths.py --target 0.998
"""
from pathlib import Path
import argparse, hashlib, json, platform, sys, time
import numpy as np
import pandas as pd
import scipy

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'code'))
import controlled_design as design
from common import fixed_phase_pilot,criterion_ratio,CRIT
from nbm_iid_finite_grid import logarithmic_theta_grid,_iid_nbm_for_random_design,_studentizing_avar

GRID=logarithmic_theta_grid(.01,.20,121)
VARIANTS=((2,.05),(3,.05),(4,.05),(3,.03),(3,.07))

def variant_key(sp,tp):return f'sp{sp}_theta{tp:.2f}'

def run(target):
    out=ROOT/'results';out.mkdir(exist_ok=True)
    rho=design.rho_for(target);iv0=float(rho.mean());iq0=float(np.mean(rho*rho))
    rng=np.random.default_rng(design.SEEDS[target]);state_before=rng.bit_generator.state
    samples={v:[] for v in VARIANTS};baseline=[];fingerprints={};start=time.monotonic()
    for st in range(0,design.NSIM,design.BATCH):
        cur=min(design.BATCH,design.NSIM-st);y=design.simulate(rng,rho,cur)
        if st==0:fingerprints['first_observed_path_sha256']=hashlib.sha256(y[0].tobytes()).hexdigest()
        if st+cur==design.NSIM:fingerprints['last_observed_path_sha256']=hashlib.sha256(y[-1].tobytes()).hexdigest()
        for sp,tp in VARIANTS:
            iv,iq,om,_,_=fixed_phase_pilot(y,design.N,phase=sp,theta=tp)
            lam,s,theta,m=design.alg2_design(iv,iq,om)
            cr=criterion_ratio(s,m,np.full(cur,iv0),np.full(cur,iq0),GRID,design.N)
            samples[(sp,tp)].append(np.column_stack((lam,s,theta,m,cr)))
            if (sp,tp)==(3,.05):
                est=_iid_nbm_for_random_design(y,design.N,s,m)
                av=_studentizing_avar(s,m,design.N,iv,iq,om)
                z=(est-iv0)/(design.N**(-.25)*np.sqrt(av))
                baseline.append(np.column_stack((iv,iq,om,est,av,z,np.abs(z)<=CRIT)))
        if (st+cur)%1000==0:
            print(json.dumps(dict(target=target,completed=st+cur,elapsed_seconds=round(time.monotonic()-start,1))),flush=True)
    arrays={variant_key(*v):np.concatenate(parts) for v,parts in samples.items()}
    base=np.concatenate(baseline)
    arrays['baseline_pilot_estimate_inference']=base
    oracle=2 if target<design.T23 else 3 if target<design.T34 else 4
    rows=[]
    for sp,tp in VARIANTS:
        lam,s,theta,m,cr=arrays[variant_key(sp,tp)].T
        rows.append(dict(Lambda=target,OraclePhase=oracle,PilotPhase=sp,PilotTheta=tp,
            PilotK=int(np.rint(tp*np.sqrt(design.N))),N=design.NSIM,
            OraclePhaseSelectionRate=float(np.mean(s==oracle)),MeanCR=float(np.mean(cr)),P95CR=float(np.quantile(cr,.95)),
            MeanFinalTheta=float(np.mean(theta)),SDFinalTheta=float(np.std(theta,ddof=1)),MeanFinalM=float(np.mean(m)),MeanLambdaHat=float(np.mean(lam)),
            SelectS2=float(np.mean(s==2)),SelectS3=float(np.mean(s==3)),SelectS4=float(np.mean(s==4))))
    lam,s,theta,m,cr=arrays[variant_key(3,.05)].T
    est=base[:,3];z=base[:,5];coverage=base[:,6];counts={q:float(np.mean(s==q)) for q in (2,3,4)};modal=max(counts,key=counts.get)
    row2=dict(Algorithm='Alg2',Lambda=target,N=design.N,Replications=design.NSIM,PilotPhase=3,PilotTheta=.05,PilotK=24,
        ModalFinalPhase=modal,ModalFinalRate=counts[modal],OraclePhaseSelectionRate=float(np.mean(s==oracle)),
        MeanCR=float(np.mean(cr)),P95CR=float(np.quantile(cr,.95)),Coverage95=float(np.mean(coverage)),ZMean=float(np.mean(z)),ZVariance=float(np.var(z,ddof=1)),
        AdaptiveBias=float(np.mean(est-iv0)),AdaptiveVariance=float(np.var(est-iv0,ddof=1)),AdaptiveRMSE=float(np.sqrt(np.mean((est-iv0)**2))),
        MeanFinalM=float(np.mean(m)),SelectS2=counts[2],SelectS3=counts[3],SelectS4=counts[4],MeanFinalTheta=float(np.mean(theta)))
    stem=f'common_lambda_{target:.3f}'
    np.savez_compressed(out/(stem+'.npz'),**arrays)
    pd.DataFrame(rows).to_csv(out/(stem+'_table1.csv'),index=False)
    pd.DataFrame([row2]).to_csv(out/(stem+'_table2.csv'),index=False)
    metadata=dict(target=target,n=design.N,replications=design.NSIM,batch=design.BATCH,seed=design.SEEDS[target],
        rng_generator=type(rng.bit_generator).__name__,rng_state_before=state_before,rng_state_after=rng.bit_generator.state,
        variants=[dict(pilot_phase=s,pilot_theta=t) for s,t in VARIANTS],true_iv=iv0,true_iq=iq0,
        design_array_columns=['lambda_hat','selected_phase','final_theta','final_m','criterion_ratio'],
        baseline_array_columns=['pilot_iv','pilot_iq','pilot_omega2','estimate','studentizing_avar','z','covered95'],
        python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,pandas=pd.__version__,
        elapsed_seconds=time.monotonic()-start,**fingerprints)
    (out/(stem+'.json')).write_text(json.dumps(metadata,indent=2)+'\n')
    print(pd.DataFrame(rows).to_string(index=False),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--target',type=float,choices=design.TARGETS,required=True)
    run(parser.parse_args().target)
